
from __future__ import annotations

# --- standard library ------------------------------------------------------
import csv
import json
import os
import shutil
import sqlite3
from calendar import month_name
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable, DefaultDict, Dict, Iterable, List, Optional, Tuple

# --- GUI ---------------------------------------------------------------------
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

# --- charts --------------------------------------------------------------
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

# --- PDF receipts/reports --------------------------------------------------
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer

# --- Excel export ------------------------------------------------------------
import openpyxl
from openpyxl.styles import Font, PatternFill


# ============================================================================
# --- from config.py ---------------------------------------------------
# ============================================================================
APP_DIR = Path.home() / ".expense_tracker"
CONFIG_FILE = APP_DIR / "config.json"
DEFAULT_DB_PATH = str(APP_DIR / "expenses.db")


@dataclass
class AppConfig:
    """Simple, serializable container for all user-configurable settings."""

    currency_symbol: str = "\u20b9"          # ₹
    theme: str = "light"                     # "light" or "dark"
    default_payment_mode: str = "Cash"       # "Cash" or "UPI"
    auto_save: bool = True
    backup_folder: str = str(APP_DIR / "backups")
    export_folder: str = str(APP_DIR / "exports")
    db_path: str = DEFAULT_DB_PATH
    window_geometry: str = "1280x800"

    def to_dict(self) -> dict:
        return asdict(self)

    @staticmethod
    def from_dict(data: dict) -> "AppConfig":
        valid_keys = AppConfig().to_dict().keys()
        filtered = {k: v for k, v in data.items() if k in valid_keys}
        return AppConfig(**filtered)


class ConfigManager:
    """Responsible for reading/writing the AppConfig to disk."""

    def __init__(self, config_path: Path = CONFIG_FILE):
        self.config_path = config_path
        self.config = self._load()

    def _load(self) -> AppConfig:
        APP_DIR.mkdir(parents=True, exist_ok=True)
        Path(DEFAULT_DB_PATH).parent.mkdir(parents=True, exist_ok=True)
        if self.config_path.exists():
            try:
                with open(self.config_path, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                return AppConfig.from_dict(data)
            except (json.JSONDecodeError, OSError):
                return AppConfig()
        return AppConfig()

    def save(self) -> None:
        APP_DIR.mkdir(parents=True, exist_ok=True)
        with open(self.config_path, "w", encoding="utf-8") as fh:
            json.dump(self.config.to_dict(), fh, indent=2)

    def update(self, **kwargs) -> None:
        for key, value in kwargs.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
        self.save()


# ============================================================================
# --- from event_bus.py ------------------------------------------------
# ============================================================================
# Central event name used across the whole application whenever expense data
# is added, edited, deleted, or a "purchased" flag is toggled.
DATA_CHANGED = "data_changed"


class EventBus:
    """A tiny synchronous pub/sub bus."""

    def __init__(self) -> None:
        self._subscribers: DefaultDict[str, List[Callable[..., None]]] = defaultdict(list)

    def subscribe(self, event_name: str, callback: Callable[..., None]) -> None:
        """Register `callback` to be invoked whenever `event_name` is published."""
        self._subscribers[event_name].append(callback)

    def unsubscribe(self, event_name: str, callback: Callable[..., None]) -> None:
        if callback in self._subscribers[event_name]:
            self._subscribers[event_name].remove(callback)

    def publish(self, event_name: str, *args, **kwargs) -> None:
        """Notify all subscribers of `event_name`. Errors in one subscriber
        should not prevent others from being notified."""
        for callback in list(self._subscribers[event_name]):
            try:
                callback(*args, **kwargs)
            except Exception as exc:  # pragma: no cover - defensive UI glue
                print(f"[EventBus] subscriber error for '{event_name}': {exc}")


# ============================================================================
# --- from models.py ---------------------------------------------------
# ============================================================================
@dataclass
class Expense:
    """Represents a single expense record.

    `purchased` is the single most important flag in the whole application:
    when False, the expense is stored but excluded from every total,
    summary, report, chart and dashboard figure until it is checked.
    """

    id: Optional[int]
    date: str                      # "YYYY-MM-DD"
    month_year: str                # "MM-YYYY"
    product: str
    category: str
    amount: float
    payment_mode: str              # "Cash" or "UPI"
    notes: str = ""
    purchased: bool = True
    deduct_from_account: bool = False   # if True, amount is withdrawn from the
                                         # matching Cash/UPI account balance
    created_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))

    @staticmethod
    def from_row(row) -> "Expense":
        """Build an Expense from a sqlite3.Row (or ordered tuple matching
        the column order used throughout database.py)."""
        row_keys = row.keys() if hasattr(row, "keys") else []
        return Expense(
            id=row["id"],
            date=row["date"],
            month_year=row["month_year"],
            product=row["product"],
            category=row["category"],
            amount=row["amount"],
            payment_mode=row["payment_mode"],
            notes=row["notes"] or "",
            purchased=bool(row["purchased"]),
            deduct_from_account=bool(row["deduct_from_account"]) if "deduct_from_account" in row_keys else False,
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )


@dataclass
class Income:

    id: Optional[int]
    month_year: str            # "MM-YYYY"
    amount: float
    notes: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))

    @staticmethod
    def from_row(row) -> "Income":
        return Income(
            id=row["id"],
            month_year=row["month_year"],
            amount=row["amount"],
            notes=row["notes"] or "",
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )


# ============================================================================
# --- from database.py -------------------------------------------------
# ============================================================================
SCHEMA = """
CREATE TABLE IF NOT EXISTS expenses (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    date          TEXT NOT NULL,
    month_year    TEXT NOT NULL,
    product       TEXT NOT NULL,
    category      TEXT NOT NULL,
    amount        REAL NOT NULL,
    payment_mode  TEXT NOT NULL,
    notes         TEXT,
    purchased     INTEGER NOT NULL DEFAULT 1,
    deduct_from_account INTEGER NOT NULL DEFAULT 0,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS categories (
    id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS income (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    month_year    TEXT UNIQUE NOT NULL,
    amount        REAL NOT NULL,
    notes         TEXT,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS account_balances (
    account TEXT PRIMARY KEY,
    balance REAL NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS transactions (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp         TEXT NOT NULL,
    type              TEXT NOT NULL,   -- deposit | expense_deduction | expense_reversal | transfer_out | transfer_in
    account           TEXT NOT NULL,   -- 'cash' or 'upi'
    amount            REAL NOT NULL,   -- signed: positive = credit, negative = debit
    balance_after     REAL NOT NULL,
    expense_id        INTEGER,
    transfer_group_id TEXT,
    notes             TEXT
);

CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(date);
CREATE INDEX IF NOT EXISTS idx_expenses_month_year ON expenses(month_year);
CREATE INDEX IF NOT EXISTS idx_expenses_category ON expenses(category);
CREATE INDEX IF NOT EXISTS idx_expenses_purchased ON expenses(purchased);
CREATE INDEX IF NOT EXISTS idx_transactions_account ON transactions(account);
CREATE INDEX IF NOT EXISTS idx_transactions_timestamp ON transactions(timestamp);
"""

ACCOUNTS = ("cash", "upi")

DEFAULT_CATEGORIES = [
    "Groceries", "Rent", "Utilities", "Transport", "Food & Dining",
    "Entertainment", "Health", "Shopping", "Education", "Miscellaneous",
]


class DatabaseManager:
    """Thin, safe wrapper around a single SQLite database file."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        self._last_deleted: Optional[Expense] = None  # for "undo last delete"
        self._init_schema()

    # ------------------------------------------------------------------ #
    # Setup
    # ------------------------------------------------------------------ #
    def _init_schema(self) -> None:
        with self._conn:
            self._conn.executescript(SCHEMA)
            existing = {r["name"] for r in self._conn.execute("SELECT name FROM categories")}
            for cat in DEFAULT_CATEGORIES:
                if cat not in existing:
                    self._conn.execute("INSERT OR IGNORE INTO categories(name) VALUES (?)", (cat,))
            for account in ACCOUNTS:
                self._conn.execute(
                    "INSERT OR IGNORE INTO account_balances(account, balance) VALUES (?, 0)",
                    (account,),
                )
            self._migrate_legacy_columns()

    def _migrate_legacy_columns(self) -> None:
        """Add columns introduced after the original release to any
        pre-existing database file, so older data files keep working."""
        cols = {r["name"] for r in self._conn.execute("PRAGMA table_info(expenses)")}
        if "deduct_from_account" not in cols:
            with self._conn:
                self._conn.execute(
                    "ALTER TABLE expenses ADD COLUMN deduct_from_account INTEGER NOT NULL DEFAULT 0"
                )

    def close(self) -> None:
        self._conn.close()

    # ------------------------------------------------------------------ #
    # Category management
    # ------------------------------------------------------------------ #
    def get_categories(self) -> List[str]:
        rows = self._conn.execute("SELECT name FROM categories ORDER BY name").fetchall()
        return [r["name"] for r in rows]

    def add_category(self, name: str) -> None:
        name = name.strip()
        if not name:
            return
        with self._conn:
            self._conn.execute("INSERT OR IGNORE INTO categories(name) VALUES (?)", (name,))

    def delete_category(self, name: str) -> None:
        with self._conn:
            self._conn.execute("DELETE FROM categories WHERE name = ?", (name,))

    # ------------------------------------------------------------------ #
    # Account Balances (Cash / UPI) and Transaction Ledger
    # ------------------------------------------------------------------ #
    @staticmethod
    def _account_key(payment_mode: str) -> str:
        """Map an expense's payment mode to its account ledger key."""
        return "cash" if payment_mode == "Cash" else "upi"

    def _apply_balance_change(
        self, account: str, signed_amount: float, txn_type: str,
        expense_id: Optional[int] = None, transfer_group_id: Optional[str] = None,
        notes: str = "",
    ) -> float:
        """Atomically update an account's cached balance AND append a row
        to the transaction ledger. `signed_amount` is positive for a
        credit (deposit, transfer-in, expense reversal) and negative for a
        debit (expense deduction, transfer-out). Returns the new balance."""
        if account not in ACCOUNTS:
            raise ValueError(f"Unknown account: {account}")
        now = datetime.now().isoformat(timespec="seconds")
        with self._conn:
            current = self._conn.execute(
                "SELECT balance FROM account_balances WHERE account = ?", (account,)
            ).fetchone()["balance"]
            new_balance = current + signed_amount
            self._conn.execute(
                "UPDATE account_balances SET balance = ? WHERE account = ?",
                (new_balance, account),
            )
            self._conn.execute(
                """INSERT INTO transactions
                   (timestamp, type, account, amount, balance_after, expense_id,
                    transfer_group_id, notes)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (now, txn_type, account, signed_amount, new_balance,
                 expense_id, transfer_group_id, notes),
            )
        return new_balance

    def get_balance(self, account: str) -> float:
        row = self._conn.execute(
            "SELECT balance FROM account_balances WHERE account = ?", (account,)
        ).fetchone()
        return float(row["balance"]) if row else 0.0

    def get_cash_balance(self) -> float:
        return self.get_balance("cash")

    def get_upi_balance(self) -> float:
        return self.get_balance("upi")

    def get_total_balance(self) -> float:
        """Total Balance = Cash Balance + UPI Balance."""
        return self.get_cash_balance() + self.get_upi_balance()

    def get_available_balance(self) -> float:
        """The Available Balance reflects only expenses explicitly marked
        'Deduct Amount from Account'. Since account balances are only ever
        touched by deposits, deduction-marked expenses, and transfers, this
        is equal to the Total Balance by construction - exposed as its own
        figure because that is what the accounts screen and dashboard
        display to the user."""
        return self.get_total_balance()

    def deposit_funds(self, account: str, amount: float, notes: str = "") -> float:
        """Add funds (e.g. income) directly into an account's balance."""
        if amount <= 0:
            raise ValueError("Deposit amount must be positive.")
        return self._apply_balance_change(account, amount, "deposit", notes=notes)

    def transfer_funds(self, from_account: str, to_account: str, amount: float, notes: str = "") -> None:
        """Move money between Cash and UPI. Total Balance is unchanged."""
        if amount <= 0:
            raise ValueError("Transfer amount must be positive.")
        if from_account == to_account:
            raise ValueError("Source and destination accounts must be different.")
        current = self.get_balance(from_account)
        if amount > current:
            raise ValueError(
                f"Insufficient balance in {from_account.upper()} account "
                f"(available: {current:,.2f})."
            )
        group_id = f"TRF-{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        self._apply_balance_change(from_account, -amount, "transfer_out",
                                    transfer_group_id=group_id, notes=notes)
        self._apply_balance_change(to_account, amount, "transfer_in",
                                    transfer_group_id=group_id, notes=notes)

    def get_transactions(
        self, account_filter: str = "", type_filter: str = "",
        limit: int = 200, offset: int = 0,
    ) -> Tuple[List[dict], int]:
        """Return (page_of_transactions, total_count) - the complete,
        paginated transaction history for income deposits, expense
        deductions/reversals, and balance transfers."""
        clauses = []
        params: List = []
        if account_filter:
            clauses.append("account = ?")
            params.append(account_filter)
        if type_filter:
            clauses.append("type = ?")
            params.append(type_filter)
        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""

        total = self._conn.execute(
            f"SELECT COUNT(*) AS c FROM transactions {where_sql}", params
        ).fetchone()["c"]

        rows = self._conn.execute(
            f"""SELECT * FROM transactions {where_sql}
                ORDER BY id DESC LIMIT ? OFFSET ?""",
            params + [limit, offset],
        ).fetchall()

        return [dict(r) for r in rows], total

    # ------------------------------------------------------------------ #
    # Monthly Income (OPTIONAL - a month may or may not have one)
    # ------------------------------------------------------------------ #
    def set_income(self, month_year: str, amount: float, notes: str = "") -> None:
        """Create or update the (single, optional) income entry for a
        given month. Passing amount <= 0 together with delete_income() is
        how a month's income can be cleared entirely."""
        now = datetime.now().isoformat(timespec="seconds")
        with self._conn:
            self._conn.execute(
                """INSERT INTO income (month_year, amount, notes, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(month_year) DO UPDATE SET
                       amount = excluded.amount,
                       notes = excluded.notes,
                       updated_at = excluded.updated_at""",
                (month_year, amount, notes, now, now),
            )

    def get_income(self, month_year: str) -> Optional[Income]:
        """Return the Income entry for a month, or None if not set (this
        is the normal/expected case for months with no income recorded)."""
        row = self._conn.execute(
            "SELECT * FROM income WHERE month_year = ?", (month_year,)
        ).fetchone()
        return Income.from_row(row) if row else None

    def delete_income(self, month_year: str) -> None:
        with self._conn:
            self._conn.execute("DELETE FROM income WHERE month_year = ?", (month_year,))

    def get_all_income(self) -> List[Income]:
        rows = self._conn.execute("SELECT * FROM income ORDER BY month_year").fetchall()
        return [Income.from_row(r) for r in rows]

    def get_year_income_total(self, year: str) -> float:
        """Sum of whatever monthly income entries exist for `year`. Months
        with no entry simply contribute nothing - income is optional."""
        row = self._conn.execute(
            "SELECT COALESCE(SUM(amount), 0) AS total FROM income WHERE month_year LIKE ?",
            [f"%-{year}"],
        ).fetchone()
        return float(row["total"])

    def get_total_income(self) -> float:
        row = self._conn.execute("SELECT COALESCE(SUM(amount), 0) AS total FROM income").fetchone()
        return float(row["total"])

    # ------------------------------------------------------------------ #
    # CRUD (expenses)
    # ------------------------------------------------------------------ #
    def add_expense(self, expense: Expense) -> int:
        """Insert a new expense. Always saved, regardless of purchased flag.
        If `deduct_from_account` is True, the amount is also withdrawn from
        the Cash/UPI balance matching `payment_mode` (a ledger entry is
        recorded either way for a full transaction history)."""
        now = datetime.now().isoformat(timespec="seconds")
        with self._conn:
            cur = self._conn.execute(
                """INSERT INTO expenses
                   (date, month_year, product, category, amount, payment_mode,
                    notes, purchased, deduct_from_account, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (expense.date, expense.month_year, expense.product, expense.category,
                 expense.amount, expense.payment_mode, expense.notes,
                 int(expense.purchased), int(expense.deduct_from_account), now, now),
            )
            new_id = cur.lastrowid
            self.add_category(expense.category)

        if expense.deduct_from_account:
            self._apply_balance_change(
                self._account_key(expense.payment_mode), -expense.amount,
                "expense_deduction", expense_id=new_id, notes=expense.product,
            )
        return new_id

    def update_expense(self, expense: Expense) -> None:
        """Update an existing expense (including toggling `purchased` or
        `deduct_from_account`). Any previously-applied account deduction is
        reversed first, then re-applied based on the new values - this
        correctly handles amount changes, payment-mode changes, and the
        deduction checkbox being turned on or off."""
        if expense.id is None:
            raise ValueError("Cannot update an expense without an id")

        old_expense = self.get_expense(expense.id)

        now = datetime.now().isoformat(timespec="seconds")
        with self._conn:
            self._conn.execute(
                """UPDATE expenses SET
                       date = ?, month_year = ?, product = ?, category = ?,
                       amount = ?, payment_mode = ?, notes = ?, purchased = ?,
                       deduct_from_account = ?, updated_at = ?
                   WHERE id = ?""",
                (expense.date, expense.month_year, expense.product, expense.category,
                 expense.amount, expense.payment_mode, expense.notes,
                 int(expense.purchased), int(expense.deduct_from_account), now, expense.id),
            )
            self.add_category(expense.category)

        if old_expense and old_expense.deduct_from_account:
            self._apply_balance_change(
                self._account_key(old_expense.payment_mode), old_expense.amount,
                "expense_reversal", expense_id=expense.id, notes=f"Edit reversal: {old_expense.product}",
            )
        if expense.deduct_from_account:
            self._apply_balance_change(
                self._account_key(expense.payment_mode), -expense.amount,
                "expense_deduction", expense_id=expense.id, notes=f"Edit: {expense.product}",
            )

    def set_purchased(self, expense_id: int, purchased: bool) -> None:
        """Fast path used by the table's checkbox toggle."""
        now = datetime.now().isoformat(timespec="seconds")
        with self._conn:
            self._conn.execute(
                "UPDATE expenses SET purchased = ?, updated_at = ? WHERE id = ?",
                (int(purchased), now, expense_id),
            )

    def set_deduct_from_account(self, expense_id: int, deduct: bool) -> None:
        """Quick toggle (e.g. from the table's context menu). Applies or
        reverses the corresponding account balance change as needed."""
        expense = self.get_expense(expense_id)
        if expense is None or expense.deduct_from_account == deduct:
            return
        now = datetime.now().isoformat(timespec="seconds")
        with self._conn:
            self._conn.execute(
                "UPDATE expenses SET deduct_from_account = ?, updated_at = ? WHERE id = ?",
                (int(deduct), now, expense_id),
            )
        if deduct:
            self._apply_balance_change(
                self._account_key(expense.payment_mode), -expense.amount,
                "expense_deduction", expense_id=expense_id, notes=f"Toggle on: {expense.product}",
            )
        else:
            self._apply_balance_change(
                self._account_key(expense.payment_mode), expense.amount,
                "expense_reversal", expense_id=expense_id, notes=f"Toggle off: {expense.product}",
            )

    def delete_expense(self, expense_id: int) -> None:
        row = self._conn.execute("SELECT * FROM expenses WHERE id = ?", (expense_id,)).fetchone()
        if row is not None:
            self._last_deleted = Expense.from_row(row)
        with self._conn:
            self._conn.execute("DELETE FROM expenses WHERE id = ?", (expense_id,))
        if self._last_deleted is not None and self._last_deleted.deduct_from_account:
            self._apply_balance_change(
                self._account_key(self._last_deleted.payment_mode), self._last_deleted.amount,
                "expense_reversal", expense_id=expense_id, notes=f"Delete reversal: {self._last_deleted.product}",
            )

    def undo_last_delete(self) -> Optional[Expense]:
        """Restore the most recently deleted expense, if any. Returns the
        restored Expense (with its new id) or None if nothing to undo."""
        if self._last_deleted is None:
            return None
        expense = self._last_deleted
        expense.id = None
        new_id = self.add_expense(expense)
        expense.id = new_id
        self._last_deleted = None
        return expense

    def duplicate_expense(self, expense_id: int) -> Optional[int]:
        row = self._conn.execute("SELECT * FROM expenses WHERE id = ?", (expense_id,)).fetchone()
        if row is None:
            return None
        expense = Expense.from_row(row)
        expense.id = None
        expense.date = datetime.now().strftime("%Y-%m-%d")
        expense.month_year = datetime.now().strftime("%m-%Y")
        return self.add_expense(expense)

    def get_expense(self, expense_id: int) -> Optional[Expense]:
        row = self._conn.execute("SELECT * FROM expenses WHERE id = ?", (expense_id,)).fetchone()
        return Expense.from_row(row) if row else None

    # ------------------------------------------------------------------ #
    # Querying / filtering / sorting / pagination
    # ------------------------------------------------------------------ #
    def query_expenses(
        self,
        search: str = "",
        date_filter: str = "",
        month_filter: str = "",
        year_filter: str = "",
        category_filter: str = "",
        payment_mode_filter: str = "",
        purchased_filter: str = "all",   # "all" | "purchased" | "pending"
        sort_by: str = "date",
        sort_desc: bool = True,
        limit: int = 200,
        offset: int = 0,
    ) -> Tuple[List[Expense], int]:
        """Return (rows_for_current_page, total_matching_count)."""
        clauses = []
        params: List = []

        if search:
            clauses.append("(product LIKE ? OR notes LIKE ? OR category LIKE ?)")
            like = f"%{search}%"
            params.extend([like, like, like])
        if date_filter:
            clauses.append("date = ?")
            params.append(date_filter)
        if month_filter:
            clauses.append("month_year = ?")
            params.append(month_filter)
        if year_filter:
            clauses.append("month_year LIKE ?")
            params.append(f"%-{year_filter}")
        if category_filter:
            clauses.append("category = ?")
            params.append(category_filter)
        if payment_mode_filter:
            clauses.append("payment_mode = ?")
            params.append(payment_mode_filter)
        if purchased_filter == "purchased":
            clauses.append("purchased = 1")
        elif purchased_filter == "pending":
            clauses.append("purchased = 0")

        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""

        sort_columns = {
            "date": "date", "amount": "amount", "product": "product",
            "category": "category", "payment_mode": "payment_mode",
        }
        sort_col = sort_columns.get(sort_by, "date")
        direction = "DESC" if sort_desc else "ASC"

        total = self._conn.execute(
            f"SELECT COUNT(*) AS c FROM expenses {where_sql}", params
        ).fetchone()["c"]

        rows = self._conn.execute(
            f"""SELECT * FROM expenses {where_sql}
                ORDER BY {sort_col} {direction}, id DESC
                LIMIT ? OFFSET ?""",
            params + [limit, offset],
        ).fetchall()

        return [Expense.from_row(r) for r in rows], total

    # ------------------------------------------------------------------ #
    # Aggregations - ALL of these only ever consider purchased = 1 rows
    # ------------------------------------------------------------------ #
    def _sum_where(self, where_sql: str, params: list) -> float:
        row = self._conn.execute(
            f"SELECT COALESCE(SUM(amount), 0) AS total FROM expenses "
            f"WHERE purchased = 1 AND {where_sql}", params
        ).fetchone()
        return float(row["total"])

    def get_today_total(self) -> float:
        today = datetime.now().strftime("%Y-%m-%d")
        return self._sum_where("date = ?", [today])

    def get_week_total(self) -> float:
        today = datetime.now().date()
        start = today - timedelta(days=today.weekday())  # Monday
        return self._sum_where("date >= ? AND date <= ?",
                                [start.isoformat(), today.isoformat()])

    def get_month_total(self, month_year: Optional[str] = None) -> float:
        month_year = month_year or datetime.now().strftime("%m-%Y")
        return self._sum_where("month_year = ?", [month_year])

    def get_year_total(self, year: Optional[str] = None) -> float:
        year = year or datetime.now().strftime("%Y")
        return self._sum_where("month_year LIKE ?", [f"%-{year}"])

    def get_grand_total(self) -> float:
        return self._sum_where("1 = 1", [])

    def get_monthly_summary(self, year: str) -> Dict[str, float]:
        """Returns {'January': total, ..., 'December': total} for `year`,
        purchased expenses only."""
        summary = {month_name[m]: 0.0 for m in range(1, 13)}
        rows = self._conn.execute(
            "SELECT month_year, SUM(amount) AS total FROM expenses "
            "WHERE purchased = 1 AND month_year LIKE ? GROUP BY month_year",
            [f"%-{year}"],
        ).fetchall()
        for r in rows:
            mm = r["month_year"].split("-")[0]
            try:
                name = month_name[int(mm)]
                summary[name] = float(r["total"])
            except (ValueError, IndexError):
                continue
        return summary

    def get_monthly_summary_with_income(self, year: str) -> Dict[str, Dict[str, Optional[float]]]:
        """Like get_monthly_summary, but also attaches each month's OPTIONAL
        income and the resulting savings (income - expense). If a month has
        no income entry, 'income' and 'savings' are None for that month so
        the UI can show a clear "-" instead of a misleading 0."""
        expense_totals = self.get_monthly_summary(year)
        result: Dict[str, Dict[str, Optional[float]]] = {}
        for month_num in range(1, 13):
            name = month_name[month_num]
            month_year = f"{month_num:02d}-{year}"
            income_entry = self.get_income(month_year)
            expense_total = expense_totals[name]
            income_amount = income_entry.amount if income_entry else None
            savings = (income_amount - expense_total) if income_amount is not None else None
            result[name] = {
                "expense": expense_total,
                "income": income_amount,
                "savings": savings,
            }
        return result

    def get_years(self) -> List[str]:
        rows = self._conn.execute(
            "SELECT DISTINCT substr(month_year, 4, 4) AS y FROM expenses ORDER BY y"
        ).fetchall()
        return [r["y"] for r in rows if r["y"]]

    def get_yearly_summary(self) -> Dict[str, float]:
        summary: Dict[str, float] = {}
        for year in self.get_years():
            summary[year] = self._sum_where("month_year LIKE ?", [f"%-{year}"])
        return summary

    def get_dashboard_stats(self) -> dict:
        purchased_count = self._conn.execute(
            "SELECT COUNT(*) AS c FROM expenses WHERE purchased = 1"
        ).fetchone()["c"]
        pending_count = self._conn.execute(
            "SELECT COUNT(*) AS c FROM expenses WHERE purchased = 0"
        ).fetchone()["c"]
        last_row = self._conn.execute(
            "SELECT * FROM expenses ORDER BY id DESC LIMIT 1"
        ).fetchone()
        highest_row = self._conn.execute(
            "SELECT * FROM expenses WHERE purchased = 1 ORDER BY amount DESC LIMIT 1"
        ).fetchone()
        most_category_row = self._conn.execute(
            "SELECT category, COUNT(*) AS c FROM expenses WHERE purchased = 1 "
            "GROUP BY category ORDER BY c DESC LIMIT 1"
        ).fetchone()
        most_payment_row = self._conn.execute(
            "SELECT payment_mode, COUNT(*) AS c FROM expenses WHERE purchased = 1 "
            "GROUP BY payment_mode ORDER BY c DESC LIMIT 1"
        ).fetchone()

        current_month_year = datetime.now().strftime("%m-%Y")
        income_entry = self.get_income(current_month_year)
        month_income = income_entry.amount if income_entry else None
        month_total = self.get_month_total()
        month_savings = (month_income - month_total) if month_income is not None else None

        return {
            "today_total": self.get_today_total(),
            "week_total": self.get_week_total(),
            "month_total": month_total,
            "year_total": self.get_year_total(),
            "grand_total": self.get_grand_total(),
            "purchased_count": purchased_count,
            "pending_count": pending_count,
            "last_expense": Expense.from_row(last_row) if last_row else None,
            "highest_expense": Expense.from_row(highest_row) if highest_row else None,
            "most_used_category": most_category_row["category"] if most_category_row else "N/A",
            "most_used_payment_mode": most_payment_row["payment_mode"] if most_payment_row else "N/A",
            "month_income": month_income,     # None if not set for this month (optional)
            "month_savings": month_savings,   # None if income not set for this month
            "cash_balance": self.get_cash_balance(),
            "upi_balance": self.get_upi_balance(),
            "total_balance": self.get_total_balance(),
            "available_balance": self.get_available_balance(),
        }

    def get_category_totals(self, purchased_only: bool = True) -> Dict[str, float]:
        where = "WHERE purchased = 1" if purchased_only else ""
        rows = self._conn.execute(
            f"SELECT category, SUM(amount) AS total FROM expenses {where} "
            f"GROUP BY category ORDER BY total DESC"
        ).fetchall()
        return {r["category"]: float(r["total"]) for r in rows}

    def get_payment_mode_totals(self, purchased_only: bool = True) -> Dict[str, float]:
        where = "WHERE purchased = 1" if purchased_only else ""
        rows = self._conn.execute(
            f"SELECT payment_mode, SUM(amount) AS total FROM expenses {where} "
            f"GROUP BY payment_mode"
        ).fetchall()
        return {r["payment_mode"]: float(r["total"]) for r in rows}

    def get_daily_totals(self, days: int = 30) -> Dict[str, float]:
        start = (datetime.now().date() - timedelta(days=days)).isoformat()
        rows = self._conn.execute(
            "SELECT date, SUM(amount) AS total FROM expenses "
            "WHERE purchased = 1 AND date >= ? GROUP BY date ORDER BY date",
            [start],
        ).fetchall()
        return {r["date"]: float(r["total"]) for r in rows}

    def get_purchased_vs_pending_counts(self) -> Tuple[int, int]:
        p = self._conn.execute("SELECT COUNT(*) c FROM expenses WHERE purchased=1").fetchone()["c"]
        u = self._conn.execute("SELECT COUNT(*) c FROM expenses WHERE purchased=0").fetchone()["c"]
        return p, u

    # ------------------------------------------------------------------ #
    # Backup / Restore
    # ------------------------------------------------------------------ #
    def backup_to(self, backup_path: str) -> None:
        Path(backup_path).parent.mkdir(parents=True, exist_ok=True)
        # Use sqlite's own backup API for a consistent, safe copy even while
        # the connection is open.
        dest = sqlite3.connect(backup_path)
        with dest:
            self._conn.backup(dest)
        dest.close()

    def restore_from(self, backup_path: str) -> None:
        if not Path(backup_path).exists():
            raise FileNotFoundError(backup_path)
        self._conn.close()
        shutil.copyfile(backup_path, self.db_path)
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    def check_duplicate(self, expense: Expense) -> bool:
        """A lightweight duplicate-entry detector: same date, product and
        amount already present."""
        row = self._conn.execute(
            "SELECT COUNT(*) AS c FROM expenses WHERE date = ? AND product = ? "
            "AND amount = ? AND (? IS NULL OR id != ?)",
            (expense.date, expense.product, expense.amount, expense.id, expense.id),
        ).fetchone()
        return row["c"] > 0


# ============================================================================
# --- from theme.py ----------------------------------------------------
# ============================================================================
LIGHT = {
    "bg": "#f4f6f8",
    "surface": "#ffffff",
    "sidebar": "#1f2a40",
    "sidebar_text": "#e8ecf3",
    "text": "#1b2430",
    "muted_text": "#5b6675",
    "accent": "#2f6feb",
    "purchased": "#1e8e3e",       # green
    "purchased_bg": "#e6f4ea",
    "pending": "#d93025",         # red
    "pending_bg": "#fce8e6",
    "border": "#d7dce2",
    "toolbar": "#eef1f5",
}

DARK = {
    "bg": "#12161f",
    "surface": "#1b212c",
    "sidebar": "#0c0f16",
    "sidebar_text": "#dfe6f2",
    "text": "#e8ecf3",
    "muted_text": "#93a0b4",
    "accent": "#5b9bff",
    "purchased": "#4caf6d",
    "purchased_bg": "#173420",
    "pending": "#ef6a63",
    "pending_bg": "#3a1e1d",
    "border": "#2a3242",
    "toolbar": "#171d28",
}


def palette(theme_name: str) -> dict:
    return DARK if theme_name == "dark" else LIGHT


def apply_theme(root: tk.Misc, theme_name: str) -> dict:
    """Configure ttk styles for the given theme and return the color palette
    in use, so widgets built afterwards can reuse the same colors."""
    colors = palette(theme_name)
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass

    root.configure(bg=colors["bg"])

    style.configure("TFrame", background=colors["bg"])
    style.configure("Surface.TFrame", background=colors["surface"])
    style.configure("Sidebar.TFrame", background=colors["sidebar"])
    style.configure("Toolbar.TFrame", background=colors["toolbar"])

    style.configure("TLabel", background=colors["bg"], foreground=colors["text"])
    style.configure("Surface.TLabel", background=colors["surface"], foreground=colors["text"])
    style.configure("Muted.TLabel", background=colors["surface"], foreground=colors["muted_text"])
    style.configure("Sidebar.TLabel", background=colors["sidebar"], foreground=colors["sidebar_text"],
                     font=("Segoe UI", 11))
    style.configure("CardTitle.TLabel", background=colors["surface"], foreground=colors["muted_text"],
                     font=("Segoe UI", 9, "bold"))
    style.configure("CardValue.TLabel", background=colors["surface"], foreground=colors["text"],
                     font=("Segoe UI", 18, "bold"))
    style.configure("Header.TLabel", background=colors["bg"], foreground=colors["text"],
                     font=("Segoe UI", 16, "bold"))

    style.configure("TButton", padding=6, font=("Segoe UI", 10))
    style.configure("Accent.TButton", background=colors["accent"], foreground="white", padding=6)
    style.map("Accent.TButton", background=[("active", colors["accent"])])

    style.configure("Sidebar.TButton", background=colors["sidebar"], foreground=colors["sidebar_text"],
                     borderwidth=0, padding=10, font=("Segoe UI", 10))
    style.map("Sidebar.TButton", background=[("active", colors["accent"])])

    style.configure("Treeview", background=colors["surface"], fieldbackground=colors["surface"],
                     foreground=colors["text"], rowheight=26, font=("Segoe UI", 10))
    style.configure("Treeview.Heading", background=colors["toolbar"], foreground=colors["text"],
                     font=("Segoe UI", 10, "bold"))
    style.map("Treeview", background=[("selected", colors["accent"])],
              foreground=[("selected", "white")])

    style.configure("TEntry", fieldbackground=colors["surface"], foreground=colors["text"])
    style.configure("TCombobox", fieldbackground=colors["surface"], foreground=colors["text"])
    style.configure("TCheckbutton", background=colors["surface"], foreground=colors["text"])
    style.configure("TNotebook", background=colors["bg"])
    style.configure("TNotebook.Tab", background=colors["toolbar"], foreground=colors["text"], padding=(12, 6))

    return colors


# ============================================================================
# --- from pdf_receipts.py ---------------------------------------------
# ============================================================================
styles = getSampleStyleSheet()
TITLE_STYLE = ParagraphStyle("TitleStyle", parent=styles["Title"], fontSize=18, spaceAfter=6)
SUB_STYLE = ParagraphStyle("SubStyle", parent=styles["Normal"], fontSize=9, textColor=colors.grey)
NORMAL = styles["Normal"]


def _receipt_number(prefix: str = "RCPT") -> str:
    return f"{prefix}-{datetime.now().strftime('%Y%m%d%H%M%S')}"


def generate_expense_receipt(
    path: str,
    expense: Expense,
    currency: str = "\u20b9",
    owner_name: Optional[str] = None,
) -> None:
    """Generate a single, individual-expense PDF receipt."""
    doc = SimpleDocTemplate(path, pagesize=A4, topMargin=25 * mm, bottomMargin=25 * mm)
    elements = []

    elements.append(Paragraph("Expense Receipt", TITLE_STYLE))
    elements.append(Paragraph(f"Receipt No: {_receipt_number()}", SUB_STYLE))
    elements.append(Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", SUB_STYLE))
    if owner_name:
        elements.append(Paragraph(f"Issued to: {owner_name}", SUB_STYLE))
    elements.append(Spacer(1, 12))

    status = "Purchased" if expense.purchased else "Pending"
    data = [
        ["Field", "Value"],
        ["Date", expense.date],
        ["Product", expense.product],
        ["Category", expense.category],
        ["Payment Mode", expense.payment_mode],
        ["Notes", expense.notes or "-"],
        ["Status", status],
        ["Amount", f"{currency}{expense.amount:,.2f}"],
    ]
    table = Table(data, colWidths=[120, 320])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2f6feb")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.white]),
        ("PADDING", (0, 0), (-1, -1), 8),
    ]))
    elements.append(table)
    elements.append(Spacer(1, 20))
    elements.append(Paragraph(
        f"Total Amount: {currency}{expense.amount:,.2f}",
        ParagraphStyle("Total", parent=styles["Heading2"]),
    ))

    doc.build(elements)


def generate_batch_receipt(
    path: str,
    title: str,
    expenses: Iterable[Expense],
    currency: str = "\u20b9",
    owner_name: Optional[str] = None,
) -> None:
    """Generate a PDF receipt for a set of expenses (daily/weekly/monthly/yearly)."""
    doc = SimpleDocTemplate(path, pagesize=A4, topMargin=20 * mm, bottomMargin=20 * mm)
    elements = []

    elements.append(Paragraph(title, TITLE_STYLE))
    elements.append(Paragraph(f"Receipt No: {_receipt_number()}", SUB_STYLE))
    elements.append(Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", SUB_STYLE))
    if owner_name:
        elements.append(Paragraph(f"Issued to: {owner_name}", SUB_STYLE))
    elements.append(Spacer(1, 12))

    data = [["Date", "Product", "Category", "Payment", "Status", "Amount"]]
    total = 0.0
    for e in expenses:
        status = "Purchased" if e.purchased else "Pending"
        if e.purchased:
            total += e.amount
        data.append([e.date, e.product, e.category, e.payment_mode, status,
                     f"{currency}{e.amount:,.2f}"])

    table = Table(data, colWidths=[60, 110, 90, 60, 60, 80], repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2f6feb")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.white]),
        ("PADDING", (0, 0), (-1, -1), 5),
    ]))
    elements.append(table)
    elements.append(Spacer(1, 16))
    elements.append(Paragraph(
        f"Total (Purchased only): {currency}{total:,.2f}",
        ParagraphStyle("Total", parent=styles["Heading2"]),
    ))

    doc.build(elements)


def generate_report_pdf(path: str, title: str, report_text: str) -> None:
    """Export the plain-text report shown in the Reports tab as a PDF."""
    doc = SimpleDocTemplate(path, pagesize=A4, topMargin=20 * mm, bottomMargin=20 * mm)
    elements = [Paragraph(title, TITLE_STYLE), Spacer(1, 10)]
    pre_style = ParagraphStyle("Pre", parent=styles["Code"], fontSize=8, leading=11)
    for line in report_text.splitlines():
        safe_line = (line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                     or "&nbsp;")
        elements.append(Paragraph(safe_line, pre_style))
    doc.build(elements)


# ============================================================================
# --- from export_import.py --------------------------------------------
# ============================================================================
CSV_HEADERS = ["id", "date", "month_year", "product", "category", "amount",
               "payment_mode", "notes", "purchased", "created_at", "updated_at"]


def export_to_csv(db: DatabaseManager, path: str) -> int:
    """Export ALL expenses (purchased and pending) to CSV. Returns row count."""
    rows, _ = db.query_expenses(purchased_filter="all", limit=10_000_000)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(CSV_HEADERS)
        for e in rows:
            writer.writerow([e.id, e.date, e.month_year, e.product, e.category,
                              e.amount, e.payment_mode, e.notes, int(e.purchased),
                              e.created_at, e.updated_at])
    return len(rows)


def export_to_excel(db: DatabaseManager, path: str) -> int:
    """Export ALL expenses to a formatted .xlsx workbook. Returns row count."""
    rows, _ = db.query_expenses(purchased_filter="all", limit=10_000_000)
    Path(path).parent.mkdir(parents=True, exist_ok=True)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Expenses"

    headers = ["Date", "Product", "Category", "Amount", "Payment Mode",
               "Notes", "Status", "Created At"]
    ws.append(headers)
    header_fill = PatternFill(start_color="2F6FEB", end_color="2F6FEB", fill_type="solid")
    for cell in ws[1]:
        cell.font = Font(color="FFFFFF", bold=True)
        cell.fill = header_fill

    green_fill = PatternFill(start_color="E6F4EA", end_color="E6F4EA", fill_type="solid")
    red_fill = PatternFill(start_color="FCE8E6", end_color="FCE8E6", fill_type="solid")

    for e in rows:
        status = "Purchased" if e.purchased else "Pending"
        ws.append([e.date, e.product, e.category, e.amount, e.payment_mode,
                   e.notes, status, e.created_at])
        fill = green_fill if e.purchased else red_fill
        for cell in ws[ws.max_row]:
            cell.fill = fill

    for col_cells in ws.columns:
        length = max(len(str(c.value)) if c.value is not None else 0 for c in col_cells)
        ws.column_dimensions[col_cells[0].column_letter].width = min(max(length + 2, 10), 40)

    wb.save(path)
    return len(rows)


def import_from_csv(db: DatabaseManager, path: str) -> int:
    """Import expenses from a CSV file matching CSV_HEADERS (id/created_at/
    updated_at columns are ignored/regenerated). Returns number imported."""
    count = 0
    with open(path, "r", newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            try:
                expense = Expense(
                    id=None,
                    date=row["date"],
                    month_year=row.get("month_year") or datetime.strptime(
                        row["date"], "%Y-%m-%d").strftime("%m-%Y"),
                    product=row["product"],
                    category=row.get("category", "Miscellaneous"),
                    amount=float(row["amount"]),
                    payment_mode=row.get("payment_mode", "Cash"),
                    notes=row.get("notes", ""),
                    purchased=str(row.get("purchased", "1")).strip() in ("1", "true", "True"),
                )
            except (KeyError, ValueError):
                continue
            db.add_expense(expense)
            count += 1
    return count


def backup_database(db: DatabaseManager, folder: str) -> str:
    Path(folder).mkdir(parents=True, exist_ok=True)
    filename = f"expense_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    dest = str(Path(folder) / filename)
    db.backup_to(dest)
    return dest


def restore_database(db: DatabaseManager, backup_path: str) -> None:
    db.restore_from(backup_path)


# ============================================================================
# --- from expense_form.py ---------------------------------------------
# ============================================================================
PAYMENT_MODES = ["Cash", "UPI"]


class ExpenseFormDialog(tk.Toplevel):
    """Add/Edit expense modal. Calls `on_saved` after a successful save."""

    def __init__(
        self,
        parent: tk.Misc,
        db: DatabaseManager,
        theme_name: str,
        on_saved: Callable[[], None],
        expense: Optional[Expense] = None,
        default_payment_mode: str = "Cash",
    ):
        super().__init__(parent)
        self.db = db
        self.on_saved = on_saved
        self.expense = expense
        self.colors = palette(theme_name)

        self.title("Edit Expense" if expense else "Add Expense")
        self.geometry("420x560")
        self.resizable(False, False)
        self.configure(bg=self.colors["surface"])
        self.transient(parent)
        self.grab_set()

        self._build_form(default_payment_mode)
        self._populate_if_editing()
        self.bind("<Return>", lambda e: self._save())
        self.bind("<Escape>", lambda e: self.destroy())

    # ------------------------------------------------------------------ #
    def _build_form(self, default_payment_mode: str) -> None:
        pad = {"padx": 16, "pady": 6}

        frm = ttk.Frame(self, style="Surface.TFrame")
        frm.pack(fill="both", expand=True)

        def label(text):
            return ttk.Label(frm, text=text, style="Surface.TLabel")

        row = 0
        label("Date (YYYY-MM-DD)").grid(row=row, column=0, sticky="w", **pad)
        self.date_var = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        date_entry = ttk.Entry(frm, textvariable=self.date_var, width=30)
        date_entry.grid(row=row, column=1, **pad)
        self.date_var.trace_add("write", self._sync_month_year)
        row += 1

        label("Month-Year (MM-YYYY)").grid(row=row, column=0, sticky="w", **pad)
        self.month_year_var = tk.StringVar(value=datetime.now().strftime("%m-%Y"))
        ttk.Entry(frm, textvariable=self.month_year_var, width=30).grid(row=row, column=1, **pad)
        row += 1

        label("Product Name").grid(row=row, column=0, sticky="w", **pad)
        self.product_var = tk.StringVar()
        ttk.Entry(frm, textvariable=self.product_var, width=30).grid(row=row, column=1, **pad)
        row += 1

        label("Category").grid(row=row, column=0, sticky="w", **pad)
        self.category_var = tk.StringVar()
        categories = self.db.get_categories()
        self.category_combo = ttk.Combobox(frm, textvariable=self.category_var,
                                            values=categories, width=27)
        self.category_combo.grid(row=row, column=1, **pad)
        row += 1

        label("Amount").grid(row=row, column=0, sticky="w", **pad)
        self.amount_var = tk.StringVar()
        ttk.Entry(frm, textvariable=self.amount_var, width=30).grid(row=row, column=1, **pad)
        row += 1

        label("Payment Mode").grid(row=row, column=0, sticky="w", **pad)
        self.payment_var = tk.StringVar(value=default_payment_mode)
        ttk.Combobox(frm, textvariable=self.payment_var, values=PAYMENT_MODES,
                     state="readonly", width=27).grid(row=row, column=1, **pad)
        row += 1

        label("Notes (optional)").grid(row=row, column=0, sticky="nw", **pad)
        self.notes_text = tk.Text(frm, width=30, height=4,
                                   bg=self.colors["surface"], fg=self.colors["text"],
                                   insertbackground=self.colors["text"])
        self.notes_text.grid(row=row, column=1, **pad)
        row += 1

        # The most important control in the whole application.
        self.purchased_var = tk.BooleanVar(value=True)
        purchased_check = tk.Checkbutton(
            frm, text="  Purchased ✔  (include in all calculations)",
            variable=self.purchased_var, onvalue=True, offvalue=False,
            fg=self.colors["purchased"], bg=self.colors["surface"],
            selectcolor=self.colors["purchased_bg"], activebackground=self.colors["surface"],
            font=("Segoe UI", 10, "bold"),
        )
        purchased_check.grid(row=row, column=0, columnspan=2, sticky="w", padx=16, pady=(10, 4))
        row += 1

        hint = ttk.Label(
            frm,
            text="Unchecked expenses are still saved, but excluded from\n"
                 "every total, report, chart and dashboard figure.",
            style="Muted.TLabel", justify="left",
        )
        hint.grid(row=row, column=0, columnspan=2, sticky="w", padx=16)
        row += 1

        # Optional: withdraw this amount from the matching Cash/UPI account.
        self.deduct_var = tk.BooleanVar(value=False)
        deduct_check = tk.Checkbutton(
            frm, text="  Deduct Amount from Account",
            variable=self.deduct_var, onvalue=True, offvalue=False,
            fg=self.colors["accent"], bg=self.colors["surface"],
            selectcolor=self.colors["purchased_bg"], activebackground=self.colors["surface"],
            font=("Segoe UI", 10, "bold"),
        )
        deduct_check.grid(row=row, column=0, columnspan=2, sticky="w", padx=16, pady=(4, 4))
        row += 1

        deduct_hint = ttk.Label(
            frm,
            text="If checked, this amount is withdrawn from the Cash/UPI\n"
                 "balance matching Payment Mode above, and appears in the\n"
                 "transaction history. If unchecked, the expense is saved but\n"
                 "no account balance is affected.",
            style="Muted.TLabel", justify="left",
        )
        deduct_hint.grid(row=row, column=0, columnspan=2, sticky="w", padx=16)
        row += 1

        btn_frame = ttk.Frame(frm, style="Surface.TFrame")
        btn_frame.grid(row=row, column=0, columnspan=2, pady=20)
        ttk.Button(btn_frame, text="Save", style="Accent.TButton",
                   command=self._save).pack(side="left", padx=8)
        ttk.Button(btn_frame, text="Cancel",
                   command=self.destroy).pack(side="left", padx=8)

    def _sync_month_year(self, *_args) -> None:
        """Auto-derive MM-YYYY from the date field, unless the user has
        already typed something different on purpose (best-effort only)."""
        text = self.date_var.get().strip()
        try:
            dt = datetime.strptime(text, "%Y-%m-%d")
            self.month_year_var.set(dt.strftime("%m-%Y"))
        except ValueError:
            pass

    def _populate_if_editing(self) -> None:
        if not self.expense:
            return
        e = self.expense
        self.date_var.set(e.date)
        self.month_year_var.set(e.month_year)
        self.product_var.set(e.product)
        self.category_var.set(e.category)
        self.amount_var.set(str(e.amount))
        self.payment_var.set(e.payment_mode)
        self.notes_text.insert("1.0", e.notes)
        self.purchased_var.set(e.purchased)
        self.deduct_var.set(e.deduct_from_account)

    # ------------------------------------------------------------------ #
    def _save(self) -> None:
        date = self.date_var.get().strip()
        month_year = self.month_year_var.get().strip()
        product = self.product_var.get().strip()
        category = self.category_var.get().strip()
        amount_raw = self.amount_var.get().strip()
        payment_mode = self.payment_var.get().strip()
        notes = self.notes_text.get("1.0", "end").strip()
        purchased = self.purchased_var.get()
        deduct_from_account = self.deduct_var.get()

        # --- Validation ---------------------------------------------------
        try:
            datetime.strptime(date, "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Invalid Date", "Date must be in YYYY-MM-DD format.")
            return
        try:
            datetime.strptime(month_year, "%m-%Y")
        except ValueError:
            messagebox.showerror("Invalid Month-Year", "Month-Year must be in MM-YYYY format.")
            return
        if not product:
            messagebox.showerror("Missing Product", "Product name is required.")
            return
        if not category:
            messagebox.showerror("Missing Category", "Category is required.")
            return
        try:
            amount = float(amount_raw)
            if amount <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid Amount", "Amount must be a positive number.")
            return
        if payment_mode not in PAYMENT_MODES:
            messagebox.showerror("Invalid Payment Mode", "Choose Cash or UPI.")
            return

        expense = Expense(
            id=self.expense.id if self.expense else None,
            date=date, month_year=month_year, product=product, category=category,
            amount=amount, payment_mode=payment_mode, notes=notes, purchased=purchased,
            deduct_from_account=deduct_from_account,
        )

        if self.db.check_duplicate(expense):
            if not messagebox.askyesno(
                "Possible Duplicate",
                "An expense with the same date, product and amount already "
                "exists. Save anyway?"
            ):
                return

        if self.expense:
            self.db.update_expense(expense)
        else:
            self.db.add_expense(expense)

        self.on_saved()
        self.destroy()


# ============================================================================
# --- from expense_table.py --------------------------------------------
# ============================================================================
PAGE_SIZE = 100


class ExpenseTableFrame(ttk.Frame):
    def __init__(self, parent, db: DatabaseManager, bus: EventBus, config_manager):
        super().__init__(parent)
        self.db = db
        self.bus = bus
        self.config_manager = config_manager
        self.colors = palette(config_manager.config.theme)

        self.page = 0
        self.sort_by = "date"
        self.sort_desc = True

        self._build_toolbar()
        self._build_table()
        self._build_pagination_bar()
        self._build_context_menu()

        self.bus.subscribe(DATA_CHANGED, lambda: self.refresh())
        self.refresh()

    # ------------------------------------------------------------------ #
    def _build_toolbar(self) -> None:
        bar = ttk.Frame(self, style="Toolbar.TFrame")
        bar.pack(fill="x", padx=8, pady=8)

        ttk.Button(bar, text="+ Add Expense", style="Accent.TButton",
                   command=self.add_expense).pack(side="left", padx=4)
        ttk.Button(bar, text="Edit", command=self.edit_selected).pack(side="left", padx=4)
        ttk.Button(bar, text="Duplicate", command=self.duplicate_selected).pack(side="left", padx=4)
        ttk.Button(bar, text="Delete", command=self.delete_selected).pack(side="left", padx=4)
        ttk.Button(bar, text="Undo Delete", command=self.undo_delete).pack(side="left", padx=4)

        ttk.Label(bar, text="Search:", style="Surface.TLabel").pack(side="left", padx=(20, 4))
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(bar, textvariable=self.search_var, width=20)
        search_entry.pack(side="left")
        search_entry.bind("<KeyRelease>", lambda e: self._debounced_refresh())

        filters = ttk.Frame(self, style="Toolbar.TFrame")
        filters.pack(fill="x", padx=8)

        ttk.Label(filters, text="Month:", style="Surface.TLabel").pack(side="left", padx=(0, 4))
        self.month_var = tk.StringVar(value="")
        ttk.Entry(filters, textvariable=self.month_var, width=8).pack(side="left", padx=(0, 12))

        ttk.Label(filters, text="Year:", style="Surface.TLabel").pack(side="left", padx=(0, 4))
        self.year_var = tk.StringVar(value="")
        ttk.Entry(filters, textvariable=self.year_var, width=6).pack(side="left", padx=(0, 12))

        ttk.Label(filters, text="Category:", style="Surface.TLabel").pack(side="left", padx=(0, 4))
        self.category_filter_var = tk.StringVar(value="")
        self.category_filter_combo = ttk.Combobox(
            filters, textvariable=self.category_filter_var,
            values=[""] + self.db.get_categories(), width=16, state="readonly")
        self.category_filter_combo.pack(side="left", padx=(0, 12))

        ttk.Label(filters, text="Payment:", style="Surface.TLabel").pack(side="left", padx=(0, 4))
        self.payment_filter_var = tk.StringVar(value="")
        ttk.Combobox(filters, textvariable=self.payment_filter_var,
                     values=["", "Cash", "UPI"], width=8, state="readonly").pack(side="left", padx=(0, 12))

        ttk.Label(filters, text="Status:", style="Surface.TLabel").pack(side="left", padx=(0, 4))
        self.status_filter_var = tk.StringVar(value="all")
        ttk.Combobox(filters, textvariable=self.status_filter_var,
                     values=["all", "purchased", "pending"], width=10,
                     state="readonly").pack(side="left", padx=(0, 12))

        ttk.Button(filters, text="Apply Filters", command=lambda: self.refresh(reset_page=True)).pack(side="left", padx=6)
        ttk.Button(filters, text="Clear Filters", command=self._clear_filters).pack(side="left", padx=6)

        self._debounce_job = None

    def _debounced_refresh(self):
        if self._debounce_job:
            self.after_cancel(self._debounce_job)
        self._debounce_job = self.after(300, lambda: self.refresh(reset_page=True))

    def _clear_filters(self):
        self.search_var.set("")
        self.month_var.set("")
        self.year_var.set("")
        self.category_filter_var.set("")
        self.payment_filter_var.set("")
        self.status_filter_var.set("all")
        self.refresh(reset_page=True)

    # ------------------------------------------------------------------ #
    def _build_table(self) -> None:
        columns = ("purchased", "deduct", "date", "product", "category", "amount", "payment_mode", "notes")
        headers = {
            "purchased": "✔", "deduct": "💳", "date": "Date", "product": "Product Name",
            "category": "Category", "amount": "Amount", "payment_mode": "Payment Mode",
            "notes": "Notes",
        }
        widths = {"purchased": 40, "deduct": 40, "date": 100, "product": 180, "category": 130,
                   "amount": 100, "payment_mode": 100, "notes": 220}

        container = ttk.Frame(self)
        container.pack(fill="both", expand=True, padx=8, pady=4)

        self.tree = ttk.Treeview(container, columns=columns, show="headings", selectmode="browse")
        for col in columns:
            self.tree.heading(col, text=headers[col], command=lambda c=col: self._on_sort_click(c))
            self.tree.column(col, width=widths[col], anchor="w")

        vsb = ttk.Scrollbar(container, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        self.tree.tag_configure("purchased_row", background=self.colors["purchased_bg"])
        self.tree.tag_configure("pending_row", background=self.colors["pending_bg"])

        self.tree.bind("<Double-1>", lambda e: self.edit_selected())
        self.tree.bind("<space>", lambda e: self._toggle_purchased_selected())
        self.tree.bind("<Button-3>", self._show_context_menu)   # right click (Win/Linux)
        self.tree.bind("<Button-2>", self._show_context_menu)   # right click (some Mac configs)
        self.tree.bind("<Delete>", lambda e: self.delete_selected())

        # Keyboard shortcuts
        self.bind_all("<Control-n>", lambda e: self.add_expense())
        self.bind_all("<Control-f>", lambda e: search_entry_focus())

        def search_entry_focus():
            pass  # placeholder hook kept simple/robust across platforms

    def _build_pagination_bar(self) -> None:
        bar = ttk.Frame(self)
        bar.pack(fill="x", padx=8, pady=(0, 8))
        self.page_label = ttk.Label(bar, text="")
        self.page_label.pack(side="left")
        ttk.Button(bar, text="◀ Prev", command=self._prev_page).pack(side="right", padx=4)
        ttk.Button(bar, text="Next ▶", command=self._next_page).pack(side="right", padx=4)

    def _build_context_menu(self) -> None:
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="Edit", command=self.edit_selected)
        self.context_menu.add_command(label="Duplicate", command=self.duplicate_selected)
        self.context_menu.add_command(label="Toggle Purchased", command=self._toggle_purchased_selected)
        self.context_menu.add_command(label="Toggle Deduction from Account", command=self._toggle_deduct_selected)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Delete", command=self.delete_selected)

    def _show_context_menu(self, event) -> None:
        row_id = self.tree.identify_row(event.y)
        if row_id:
            self.tree.selection_set(row_id)
            self.context_menu.tk_popup(event.x_root, event.y_root)

    # ------------------------------------------------------------------ #
    def _on_sort_click(self, column: str) -> None:
        if column in ("purchased", "deduct"):
            return
        if self.sort_by == column:
            self.sort_desc = not self.sort_desc
        else:
            self.sort_by = column
            self.sort_desc = True
        self.refresh()

    def _prev_page(self):
        if self.page > 0:
            self.page -= 1
            self.refresh()

    def _next_page(self):
        self.page += 1
        self.refresh()

    # ------------------------------------------------------------------ #
    def refresh(self, reset_page: bool = False) -> None:
        if reset_page:
            self.page = 0

        month_filter = self.month_var.get().strip()
        year_filter = self.year_var.get().strip()

        rows, total = self.db.query_expenses(
            search=self.search_var.get().strip(),
            month_filter=month_filter,
            year_filter=year_filter,
            category_filter=self.category_filter_var.get().strip(),
            payment_mode_filter=self.payment_filter_var.get().strip(),
            purchased_filter=self.status_filter_var.get(),
            sort_by=self.sort_by,
            sort_desc=self.sort_desc,
            limit=PAGE_SIZE,
            offset=self.page * PAGE_SIZE,
        )

        for item in self.tree.get_children():
            self.tree.delete(item)

        currency = self.config_manager.config.currency_symbol
        for e in rows:
            tag = "purchased_row" if e.purchased else "pending_row"
            check = "✔" if e.purchased else "☐"
            deduct_mark = "💳" if e.deduct_from_account else "—"
            self.tree.insert(
                "", "end", iid=str(e.id), tags=(tag,),
                values=(check, deduct_mark, e.date, e.product, e.category,
                        f"{currency}{e.amount:,.2f}", e.payment_mode, e.notes),
            )

        max_page = max(0, (total - 1) // PAGE_SIZE)
        self.page_label.config(
            text=f"Showing {min(total, self.page * PAGE_SIZE + 1)}-"
                 f"{min(total, (self.page + 1) * PAGE_SIZE)} of {total} "
                 f"(page {self.page + 1} of {max_page + 1})"
        )
        # refresh category dropdown in case a new one was added elsewhere
        self.category_filter_combo["values"] = [""] + self.db.get_categories()

    # ------------------------------------------------------------------ #
    def _selected_id(self) -> Optional[int]:
        sel = self.tree.selection()
        if not sel:
            return None
        return int(sel[0])

    def add_expense(self) -> None:
        ExpenseFormDialog(
            self, self.db, self.config_manager.config.theme,
            on_saved=lambda: self.bus.publish(DATA_CHANGED),
            default_payment_mode=self.config_manager.config.default_payment_mode,
        )

    def edit_selected(self) -> None:
        expense_id = self._selected_id()
        if expense_id is None:
            messagebox.showinfo("No Selection", "Select an expense to edit.")
            return
        expense = self.db.get_expense(expense_id)
        ExpenseFormDialog(
            self, self.db, self.config_manager.config.theme,
            on_saved=lambda: self.bus.publish(DATA_CHANGED), expense=expense,
        )

    def duplicate_selected(self) -> None:
        expense_id = self._selected_id()
        if expense_id is None:
            messagebox.showinfo("No Selection", "Select an expense to duplicate.")
            return
        self.db.duplicate_expense(expense_id)
        self.bus.publish(DATA_CHANGED)

    def delete_selected(self) -> None:
        expense_id = self._selected_id()
        if expense_id is None:
            messagebox.showinfo("No Selection", "Select an expense to delete.")
            return
        if messagebox.askyesno("Confirm Delete", "Delete this expense? This can be undone once via 'Undo Delete'."):
            self.db.delete_expense(expense_id)
            self.bus.publish(DATA_CHANGED)

    def undo_delete(self) -> None:
        restored = self.db.undo_last_delete()
        if restored:
            self.bus.publish(DATA_CHANGED)
        else:
            messagebox.showinfo("Nothing to Undo", "There is no recently deleted expense to restore.")

    def _toggle_purchased_selected(self) -> None:
        expense_id = self._selected_id()
        if expense_id is None:
            return
        expense = self.db.get_expense(expense_id)
        if expense:
            self.db.set_purchased(expense_id, not expense.purchased)
            self.bus.publish(DATA_CHANGED)

    def _toggle_deduct_selected(self) -> None:
        expense_id = self._selected_id()
        if expense_id is None:
            return
        expense = self.db.get_expense(expense_id)
        if expense:
            self.db.set_deduct_from_account(expense_id, not expense.deduct_from_account)
            self.bus.publish(DATA_CHANGED)


# ============================================================================
# --- from dashboard.py ------------------------------------------------
# ============================================================================
class StatCard(ttk.Frame):
    def __init__(self, parent, title: str):
        super().__init__(parent, style="Surface.TFrame")
        self.configure(padding=16)
        ttk.Label(self, text=title, style="CardTitle.TLabel").pack(anchor="w")
        self.value_label = ttk.Label(self, text="-", style="CardValue.TLabel")
        self.value_label.pack(anchor="w", pady=(6, 0))

    def set_value(self, text: str) -> None:
        self.value_label.config(text=text)


class DashboardFrame(ttk.Frame):
    def __init__(self, parent, db: DatabaseManager, bus: EventBus, config_manager):
        super().__init__(parent)
        self.db = db
        self.bus = bus
        self.config_manager = config_manager
        self.colors = palette(config_manager.config.theme)

        ttk.Label(self, text="Dashboard", style="Header.TLabel").pack(anchor="w", padx=16, pady=(16, 8))

        grid = ttk.Frame(self)
        grid.pack(fill="x", padx=16)

        self.cards = {}
        card_titles = [
            "Today's Expense", "This Week's Expense", "This Month's Expense",
            "This Year's Expense", "Grand Total", "Purchased Items",
            "Pending Items", "Most Used Category", "Most Used Payment Mode",
            "Monthly Income", "Savings This Month",
            "Cash Balance", "UPI Balance", "Total Balance", "Available Balance",
        ]
        cols = 3
        for i, title in enumerate(card_titles):
            card = StatCard(grid, title)
            card.grid(row=i // cols, column=i % cols, padx=8, pady=8, sticky="nsew")
            grid.columnconfigure(i % cols, weight=1)
            self.cards[title] = card

        info_frame = ttk.Frame(self, style="Surface.TFrame", padding=16)
        info_frame.pack(fill="x", padx=16, pady=(8, 16))
        ttk.Label(info_frame, text="Last Expense Added", style="CardTitle.TLabel").pack(anchor="w")
        self.last_expense_label = ttk.Label(info_frame, text="-", style="Surface.TLabel")
        self.last_expense_label.pack(anchor="w", pady=(4, 12))

        ttk.Label(info_frame, text="Highest Expense", style="CardTitle.TLabel").pack(anchor="w")
        self.highest_expense_label = ttk.Label(info_frame, text="-", style="Surface.TLabel")
        self.highest_expense_label.pack(anchor="w", pady=(4, 0))

        self.bus.subscribe(DATA_CHANGED, lambda: self.refresh())
        self.refresh()

    def refresh(self) -> None:
        stats = self.db.get_dashboard_stats()
        currency = self.config_manager.config.currency_symbol

        def money(v):
            return f"{currency}{v:,.2f}"

        self.cards["Today's Expense"].set_value(money(stats["today_total"]))
        self.cards["This Week's Expense"].set_value(money(stats["week_total"]))
        self.cards["This Month's Expense"].set_value(money(stats["month_total"]))
        self.cards["This Year's Expense"].set_value(money(stats["year_total"]))
        self.cards["Grand Total"].set_value(money(stats["grand_total"]))
        self.cards["Purchased Items"].set_value(str(stats["purchased_count"]))
        self.cards["Pending Items"].set_value(str(stats["pending_count"]))
        self.cards["Most Used Category"].set_value(stats["most_used_category"])
        self.cards["Most Used Payment Mode"].set_value(stats["most_used_payment_mode"])

        # Optional - only meaningful if the user has recorded income for
        # the current month. Shown clearly as "Not set" otherwise.
        if stats["month_income"] is not None:
            self.cards["Monthly Income"].set_value(money(stats["month_income"]))
        else:
            self.cards["Monthly Income"].set_value("Not set")

        if stats["month_savings"] is not None:
            self.cards["Savings This Month"].set_value(money(stats["month_savings"]))
        else:
            self.cards["Savings This Month"].set_value("—")

        self.cards["Cash Balance"].set_value(money(stats["cash_balance"]))
        self.cards["UPI Balance"].set_value(money(stats["upi_balance"]))
        self.cards["Total Balance"].set_value(money(stats["total_balance"]))
        self.cards["Available Balance"].set_value(money(stats["available_balance"]))

        last = stats["last_expense"]
        if last:
            status = "Purchased" if last.purchased else "Pending"
            self.last_expense_label.config(
                text=f"{last.product} — {money(last.amount)} on {last.date} ({status})"
            )
        else:
            self.last_expense_label.config(text="No expenses yet.")

        highest = stats["highest_expense"]
        if highest:
            self.highest_expense_label.config(
                text=f"{highest.product} — {money(highest.amount)} on {highest.date}"
            )
        else:
            self.highest_expense_label.config(text="No purchased expenses yet.")


# ============================================================================
# --- from income_frame.py ---------------------------------------------
# ============================================================================
class IncomeFrame(ttk.Frame):
    def __init__(self, parent, db: DatabaseManager, bus: EventBus, config_manager):
        super().__init__(parent)
        self.db = db
        self.bus = bus
        self.config_manager = config_manager

        ttk.Label(self, text="Monthly Income", style="Header.TLabel").pack(
            anchor="w", padx=16, pady=(16, 4))
        ttk.Label(
            self, style="Muted.TLabel", justify="left",
            text="Recording income is entirely optional. Set it for any month you like\n"
                 "to see Savings (Income - Expenses) on the Dashboard and Summary screens.\n"
                 "Months left blank simply won't show a Savings figure.",
        ).pack(anchor="w", padx=16, pady=(0, 12))

        form = ttk.Frame(self, style="Surface.TFrame", padding=16)
        form.pack(fill="x", padx=16, pady=8)

        ttk.Label(form, text="Month-Year (MM-YYYY)", style="Surface.TLabel").grid(
            row=0, column=0, sticky="w", padx=8, pady=6)
        self.month_year_var = tk.StringVar(value=datetime.now().strftime("%m-%Y"))
        ttk.Entry(form, textvariable=self.month_year_var, width=20).grid(
            row=0, column=1, sticky="w", padx=8, pady=6)

        ttk.Label(form, text="Income Amount", style="Surface.TLabel").grid(
            row=1, column=0, sticky="w", padx=8, pady=6)
        self.amount_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.amount_var, width=20).grid(
            row=1, column=1, sticky="w", padx=8, pady=6)

        ttk.Label(form, text="Notes (optional)", style="Surface.TLabel").grid(
            row=2, column=0, sticky="w", padx=8, pady=6)
        self.notes_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.notes_var, width=30).grid(
            row=2, column=1, sticky="w", padx=8, pady=6)

        btn_row = ttk.Frame(form, style="Surface.TFrame")
        btn_row.grid(row=3, column=0, columnspan=2, pady=(12, 0))
        ttk.Button(btn_row, text="Save Income", style="Accent.TButton",
                   command=self.save_income).pack(side="left", padx=6)
        ttk.Button(btn_row, text="Load for editing", command=self.load_selected).pack(side="left", padx=6)
        ttk.Button(btn_row, text="Clear Income for this Month", command=self.clear_income).pack(side="left", padx=6)

        # Table of all months that currently HAVE an income entry
        table_frame = ttk.LabelFrame(self, text="Months with Income Recorded")
        table_frame.pack(fill="both", expand=True, padx=16, pady=12)

        columns = ("month_year", "amount", "notes")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=12)
        self.tree.heading("month_year", text="Month-Year")
        self.tree.heading("amount", text="Income Amount")
        self.tree.heading("notes", text="Notes")
        self.tree.column("month_year", width=120)
        self.tree.column("amount", width=140)
        self.tree.column("notes", width=300)
        self.tree.pack(fill="both", expand=True, side="left")
        self.tree.bind("<Double-1>", lambda e: self.load_selected())

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")

        self.bus.subscribe(DATA_CHANGED, lambda: self.refresh())
        self.refresh()

    # ------------------------------------------------------------------ #
    def refresh(self) -> None:
        currency = self.config_manager.config.currency_symbol
        for item in self.tree.get_children():
            self.tree.delete(item)
        for income in self.db.get_all_income():
            self.tree.insert("", "end", iid=income.month_year,
                              values=(income.month_year, f"{currency}{income.amount:,.2f}", income.notes))

    def _selected_month_year(self):
        sel = self.tree.selection()
        return sel[0] if sel else None

    def load_selected(self) -> None:
        month_year = self._selected_month_year()
        if not month_year:
            messagebox.showinfo("No Selection", "Select a row to load it for editing.")
            return
        income = self.db.get_income(month_year)
        if income:
            self.month_year_var.set(income.month_year)
            self.amount_var.set(str(income.amount))
            self.notes_var.set(income.notes)

    def save_income(self) -> None:
        month_year = self.month_year_var.get().strip()
        try:
            datetime.strptime(month_year, "%m-%Y")
        except ValueError:
            messagebox.showerror("Invalid Month-Year", "Month-Year must be in MM-YYYY format.")
            return
        try:
            amount = float(self.amount_var.get().strip())
            if amount <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid Amount", "Income amount must be a positive number.")
            return

        self.db.set_income(month_year, amount, self.notes_var.get().strip())
        self.bus.publish(DATA_CHANGED)
        messagebox.showinfo("Saved", f"Income for {month_year} saved.")

    def clear_income(self) -> None:
        month_year = self.month_year_var.get().strip()
        if not self.db.get_income(month_year):
            messagebox.showinfo("Nothing to Clear", f"No income is currently recorded for {month_year}.")
            return
        if messagebox.askyesno("Confirm", f"Clear the income entry for {month_year}? "
                                           "This makes it optional/unset again, it does not affect any expenses."):
            self.db.delete_income(month_year)
            self.amount_var.set("")
            self.notes_var.set("")
            self.bus.publish(DATA_CHANGED)


# ============================================================================
# --- from accounts_frame.py -------------------------------------------
# ============================================================================
PAGE_SIZE = 100

ACCOUNT_LABELS = {"cash": "Cash", "upi": "UPI"}
TXN_TYPE_LABELS = {
    "deposit": "Deposit",
    "expense_deduction": "Expense Deduction",
    "expense_reversal": "Expense Reversal",
    "transfer_out": "Transfer Out",
    "transfer_in": "Transfer In",
}


class BalanceCard(ttk.Frame):
    def __init__(self, parent, title: str):
        super().__init__(parent, style="Surface.TFrame")
        self.configure(padding=16)
        ttk.Label(self, text=title, style="CardTitle.TLabel").pack(anchor="w")
        self.value_label = ttk.Label(self, text="-", style="CardValue.TLabel")
        self.value_label.pack(anchor="w", pady=(6, 0))

    def set_value(self, text: str) -> None:
        self.value_label.config(text=text)


class AccountsFrame(ttk.Frame):
    def __init__(self, parent, db: DatabaseManager, bus: EventBus, config_manager):
        super().__init__(parent)
        self.db = db
        self.bus = bus
        self.config_manager = config_manager
        self.page = 0

        ttk.Label(self, text="Accounts & Balance Transfer", style="Header.TLabel").pack(
            anchor="w", padx=16, pady=(16, 8))

        # --- Balance cards --------------------------------------------------
        cards_grid = ttk.Frame(self)
        cards_grid.pack(fill="x", padx=16)
        self.cards = {}
        for i, title in enumerate(["Cash Balance", "UPI Balance", "Total Balance", "Available Balance"]):
            card = BalanceCard(cards_grid, title)
            card.grid(row=0, column=i, padx=8, pady=8, sticky="nsew")
            cards_grid.columnconfigure(i, weight=1)
            self.cards[title] = card

        # --- Add Funds + Transfer forms side-by-side ------------------------
        forms_row = ttk.Frame(self)
        forms_row.pack(fill="x", padx=16, pady=8)

        deposit_box = ttk.LabelFrame(forms_row, text="Add Funds (Deposit)")
        deposit_box.pack(side="left", fill="both", expand=True, padx=(0, 8))
        ttk.Label(deposit_box, text="Account:", style="TLabel").grid(row=0, column=0, padx=8, pady=8, sticky="w")
        self.deposit_account_var = tk.StringVar(value="Cash")
        ttk.Combobox(deposit_box, textvariable=self.deposit_account_var, values=["Cash", "UPI"],
                     state="readonly", width=12).grid(row=0, column=1, padx=8, pady=8, sticky="w")
        ttk.Label(deposit_box, text="Amount:", style="TLabel").grid(row=1, column=0, padx=8, pady=8, sticky="w")
        self.deposit_amount_var = tk.StringVar()
        ttk.Entry(deposit_box, textvariable=self.deposit_amount_var, width=15).grid(
            row=1, column=1, padx=8, pady=8, sticky="w")
        ttk.Label(deposit_box, text="Notes:", style="TLabel").grid(row=2, column=0, padx=8, pady=8, sticky="w")
        self.deposit_notes_var = tk.StringVar()
        ttk.Entry(deposit_box, textvariable=self.deposit_notes_var, width=22).grid(
            row=2, column=1, padx=8, pady=8, sticky="w")
        ttk.Button(deposit_box, text="Add Funds", style="Accent.TButton",
                   command=self.add_funds).grid(row=3, column=0, columnspan=2, pady=10)

        transfer_box = ttk.LabelFrame(forms_row, text="Balance Transfer")
        transfer_box.pack(side="left", fill="both", expand=True, padx=(8, 0))
        ttk.Label(transfer_box, text="From:", style="TLabel").grid(row=0, column=0, padx=8, pady=8, sticky="w")
        self.transfer_from_var = tk.StringVar(value="Cash")
        from_combo = ttk.Combobox(transfer_box, textvariable=self.transfer_from_var, values=["Cash", "UPI"],
                                   state="readonly", width=12)
        from_combo.grid(row=0, column=1, padx=8, pady=8, sticky="w")

        ttk.Label(transfer_box, text="To:", style="TLabel").grid(row=1, column=0, padx=8, pady=8, sticky="w")
        self.transfer_to_var = tk.StringVar(value="UPI")
        ttk.Label(transfer_box, textvariable=self.transfer_to_var, style="TLabel",
                  font=("Segoe UI", 10, "bold")).grid(row=1, column=1, padx=8, pady=8, sticky="w")

        def sync_to(*_):
            self.transfer_to_var.set("UPI" if self.transfer_from_var.get() == "Cash" else "Cash")
        self.transfer_from_var.trace_add("write", sync_to)

        ttk.Label(transfer_box, text="Amount:", style="TLabel").grid(row=2, column=0, padx=8, pady=8, sticky="w")
        self.transfer_amount_var = tk.StringVar()
        ttk.Entry(transfer_box, textvariable=self.transfer_amount_var, width=15).grid(
            row=2, column=1, padx=8, pady=8, sticky="w")
        ttk.Label(transfer_box, text="Notes:", style="TLabel").grid(row=3, column=0, padx=8, pady=8, sticky="w")
        self.transfer_notes_var = tk.StringVar()
        ttk.Entry(transfer_box, textvariable=self.transfer_notes_var, width=22).grid(
            row=3, column=1, padx=8, pady=8, sticky="w")
        ttk.Button(transfer_box, text="Transfer", style="Accent.TButton",
                   command=self.make_transfer).grid(row=4, column=0, columnspan=2, pady=10)

        # --- Transaction history --------------------------------------------
        history_box = ttk.LabelFrame(self, text="Transaction History")
        history_box.pack(fill="both", expand=True, padx=16, pady=(8, 16))

        filter_row = ttk.Frame(history_box)
        filter_row.pack(fill="x", padx=8, pady=6)
        ttk.Label(filter_row, text="Account:", style="TLabel").pack(side="left")
        self.account_filter_var = tk.StringVar(value="")
        ttk.Combobox(filter_row, textvariable=self.account_filter_var,
                     values=["", "Cash", "UPI"], state="readonly", width=10).pack(side="left", padx=(4, 16))
        ttk.Label(filter_row, text="Type:", style="TLabel").pack(side="left")
        self.type_filter_var = tk.StringVar(value="")
        ttk.Combobox(filter_row, textvariable=self.type_filter_var,
                     values=[""] + list(TXN_TYPE_LABELS.values()),
                     state="readonly", width=20).pack(side="left", padx=(4, 16))
        ttk.Button(filter_row, text="Apply", command=lambda: self.refresh(reset_page=True)).pack(side="left")

        columns = ("timestamp", "type", "account", "amount", "balance_after", "notes")
        self.tree = ttk.Treeview(history_box, columns=columns, show="headings", height=12)
        headers = {"timestamp": "Date/Time", "type": "Type", "account": "Account",
                   "amount": "Amount", "balance_after": "Balance After", "notes": "Notes"}
        widths = {"timestamp": 150, "type": 150, "account": 70, "amount": 110,
                  "balance_after": 120, "notes": 220}
        for col in columns:
            self.tree.heading(col, text=headers[col])
            self.tree.column(col, width=widths[col], anchor="w")
        self.tree.pack(fill="both", expand=True, padx=8)

        page_bar = ttk.Frame(history_box)
        page_bar.pack(fill="x", padx=8, pady=6)
        self.page_label = ttk.Label(page_bar, text="")
        self.page_label.pack(side="left")
        ttk.Button(page_bar, text="◀ Prev", command=self._prev_page).pack(side="right", padx=4)
        ttk.Button(page_bar, text="Next ▶", command=self._next_page).pack(side="right", padx=4)

        self.bus.subscribe(DATA_CHANGED, lambda: self.refresh())
        self.refresh()

    # ------------------------------------------------------------------ #
    def _prev_page(self):
        if self.page > 0:
            self.page -= 1
            self.refresh()

    def _next_page(self):
        self.page += 1
        self.refresh()

    def refresh(self, reset_page: bool = False) -> None:
        if reset_page:
            self.page = 0
        currency = self.config_manager.config.currency_symbol

        cash = self.db.get_cash_balance()
        upi = self.db.get_upi_balance()
        total = self.db.get_total_balance()
        available = self.db.get_available_balance()
        self.cards["Cash Balance"].set_value(f"{currency}{cash:,.2f}")
        self.cards["UPI Balance"].set_value(f"{currency}{upi:,.2f}")
        self.cards["Total Balance"].set_value(f"{currency}{total:,.2f}")
        self.cards["Available Balance"].set_value(f"{currency}{available:,.2f}")

        account_filter = self.account_filter_var.get().strip().lower()
        type_label = self.type_filter_var.get().strip()
        type_filter = ""
        for key, label in TXN_TYPE_LABELS.items():
            if label == type_label:
                type_filter = key
                break

        txns, total_count = self.db.get_transactions(
            account_filter=account_filter, type_filter=type_filter,
            limit=PAGE_SIZE, offset=self.page * PAGE_SIZE,
        )

        for item in self.tree.get_children():
            self.tree.delete(item)
        for t in txns:
            self.tree.insert(
                "", "end",
                values=(
                    t["timestamp"],
                    TXN_TYPE_LABELS.get(t["type"], t["type"]),
                    ACCOUNT_LABELS.get(t["account"], t["account"]),
                    f"{currency}{t['amount']:,.2f}",
                    f"{currency}{t['balance_after']:,.2f}",
                    t["notes"] or "",
                ),
            )

        max_page = max(0, (total_count - 1) // PAGE_SIZE)
        self.page_label.config(
            text=f"Showing {min(total_count, self.page * PAGE_SIZE + 1)}-"
                 f"{min(total_count, (self.page + 1) * PAGE_SIZE)} of {total_count} "
                 f"(page {self.page + 1} of {max_page + 1})"
        )

    # ------------------------------------------------------------------ #
    def add_funds(self) -> None:
        account = "cash" if self.deposit_account_var.get() == "Cash" else "upi"
        try:
            amount = float(self.deposit_amount_var.get().strip())
            if amount <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid Amount", "Enter a positive deposit amount.")
            return
        self.db.deposit_funds(account, amount, self.deposit_notes_var.get().strip())
        self.deposit_amount_var.set("")
        self.deposit_notes_var.set("")
        self.bus.publish(DATA_CHANGED)
        messagebox.showinfo("Funds Added", f"{self.config_manager.config.currency_symbol}{amount:,.2f} "
                                            f"added to {self.deposit_account_var.get()}.")

    def make_transfer(self) -> None:
        from_account = "cash" if self.transfer_from_var.get() == "Cash" else "upi"
        to_account = "upi" if from_account == "cash" else "cash"
        try:
            amount = float(self.transfer_amount_var.get().strip())
            if amount <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid Amount", "Enter a positive transfer amount.")
            return
        try:
            self.db.transfer_funds(from_account, to_account, amount, self.transfer_notes_var.get().strip())
        except ValueError as exc:
            messagebox.showerror("Transfer Failed", str(exc))
            return
        self.transfer_amount_var.set("")
        self.transfer_notes_var.set("")
        self.bus.publish(DATA_CHANGED)
        messagebox.showinfo(
            "Transfer Complete",
            f"{self.config_manager.config.currency_symbol}{amount:,.2f} moved from "
            f"{self.transfer_from_var.get()} to {ACCOUNT_LABELS[to_account]}. "
            f"Total Balance is unchanged.",
        )


# ============================================================================
# --- from summary.py --------------------------------------------------
# ============================================================================
class SummaryFrame(ttk.Frame):
    def __init__(self, parent, db: DatabaseManager, bus: EventBus, config_manager):
        super().__init__(parent)
        self.db = db
        self.bus = bus
        self.config_manager = config_manager

        ttk.Label(self, text="Monthly & Yearly Summary", style="Header.TLabel").pack(
            anchor="w", padx=16, pady=(16, 8))

        top = ttk.Frame(self)
        top.pack(fill="x", padx=16)
        ttk.Label(top, text="Year:", style="TLabel").pack(side="left")
        self.year_var = tk.StringVar(value=str(datetime.now().year))
        self.year_combo = ttk.Combobox(top, textvariable=self.year_var, width=8, state="readonly")
        self.year_combo.pack(side="left", padx=8)
        self.year_combo.bind("<<ComboboxSelected>>", lambda e: self.refresh())

        body = ttk.Frame(self)
        body.pack(fill="both", expand=True, padx=16, pady=12)

        # Monthly table
        monthly_frame = ttk.LabelFrame(body, text="Monthly Summary")
        monthly_frame.pack(side="left", fill="both", expand=True, padx=(0, 8))
        self.monthly_tree = ttk.Treeview(
            monthly_frame, columns=("month", "total", "income", "savings"),
            show="headings", height=13)
        self.monthly_tree.heading("month", text="Month")
        self.monthly_tree.heading("total", text="Expense (Purchased)")
        self.monthly_tree.heading("income", text="Income")
        self.monthly_tree.heading("savings", text="Savings")
        self.monthly_tree.column("month", width=110)
        self.monthly_tree.column("total", width=140)
        self.monthly_tree.column("income", width=130)
        self.monthly_tree.column("savings", width=110)
        self.monthly_tree.pack(fill="both", expand=True)

        # Yearly table
        yearly_frame = ttk.LabelFrame(body, text="Yearly Summary")
        yearly_frame.pack(side="left", fill="both", expand=True, padx=(8, 0))
        self.yearly_tree = ttk.Treeview(
            yearly_frame, columns=("year", "total", "income", "savings"),
            show="headings", height=13)
        self.yearly_tree.heading("year", text="Year")
        self.yearly_tree.heading("total", text="Expense (Purchased)")
        self.yearly_tree.heading("income", text="Income")
        self.yearly_tree.heading("savings", text="Savings")
        self.yearly_tree.column("year", width=110)
        self.yearly_tree.column("total", width=140)
        self.yearly_tree.column("income", width=130)
        self.yearly_tree.column("savings", width=110)
        self.yearly_tree.pack(fill="both", expand=True)

        self.bus.subscribe(DATA_CHANGED, lambda: self.refresh())
        self.refresh()

    def refresh(self) -> None:
        currency = self.config_manager.config.currency_symbol
        years = self.db.get_years() or [str(datetime.now().year)]
        self.year_combo["values"] = years
        if self.year_var.get() not in years:
            self.year_var.set(years[-1])

        for item in self.monthly_tree.get_children():
            self.monthly_tree.delete(item)
        monthly = self.db.get_monthly_summary_with_income(self.year_var.get())
        for month, data in monthly.items():
            income_text = f"{currency}{data['income']:,.2f}" if data["income"] is not None else "—"
            savings_text = f"{currency}{data['savings']:,.2f}" if data["savings"] is not None else "—"
            self.monthly_tree.insert(
                "", "end",
                values=(month, f"{currency}{data['expense']:,.2f}", income_text, savings_text),
            )

        for item in self.yearly_tree.get_children():
            self.yearly_tree.delete(item)
        yearly = self.db.get_yearly_summary()
        for year, total in sorted(yearly.items()):
            year_income_entries = [i for i in self.db.get_all_income() if i.month_year.endswith(f"-{year}")]
            if year_income_entries:
                year_income = sum(i.amount for i in year_income_entries)
                income_text = f"{currency}{year_income:,.2f}"
                savings_text = f"{currency}{(year_income - total):,.2f}"
            else:
                income_text = "—"
                savings_text = "—"
            self.yearly_tree.insert("", "end", values=(year, f"{currency}{total:,.2f}", income_text, savings_text))


# ============================================================================
# --- from charts.py ---------------------------------------------------
# ============================================================================
matplotlib.use("TkAgg")


CHART_OPTIONS = [
    "Monthly Expense (Bar)",
    "Category Breakdown (Pie)",
    "Yearly Expense (Line)",
    "Daily Expense Trend (Last 30 Days)",
    "Payment Mode (Bar)",
    "Purchased vs Pending (Pie)",
]


class ChartsFrame(ttk.Frame):
    def __init__(self, parent, db: DatabaseManager, bus: EventBus, config_manager):
        super().__init__(parent)
        self.db = db
        self.bus = bus
        self.config_manager = config_manager

        ttk.Label(self, text="Charts", style="Header.TLabel").pack(anchor="w", padx=16, pady=(16, 8))

        top = ttk.Frame(self)
        top.pack(fill="x", padx=16)
        ttk.Label(top, text="Chart type:", style="TLabel").pack(side="left")
        self.chart_var = tk.StringVar(value=CHART_OPTIONS[0])
        combo = ttk.Combobox(top, textvariable=self.chart_var, values=CHART_OPTIONS,
                              state="readonly", width=36)
        combo.pack(side="left", padx=8)
        combo.bind("<<ComboboxSelected>>", lambda e: self.refresh())

        self.year_var = tk.StringVar(value=str(datetime.now().year))
        ttk.Label(top, text="Year (for bar/line):", style="TLabel").pack(side="left", padx=(20, 4))
        self.year_combo = ttk.Combobox(top, textvariable=self.year_var, width=8, state="readonly")
        self.year_combo.pack(side="left")
        self.year_combo.bind("<<ComboboxSelected>>", lambda e: self.refresh())

        self.canvas_frame = ttk.Frame(self)
        self.canvas_frame.pack(fill="both", expand=True, padx=16, pady=12)

        self.figure = Figure(figsize=(7, 5), dpi=100)
        self.canvas = FigureCanvasTkAgg(self.figure, master=self.canvas_frame)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

        self.bus.subscribe(DATA_CHANGED, lambda: self.refresh())
        self.refresh()

    # ------------------------------------------------------------------ #
    def refresh(self) -> None:
        years = self.db.get_years() or [str(datetime.now().year)]
        self.year_combo["values"] = years
        if self.year_var.get() not in years:
            self.year_var.set(years[-1])

        self.figure.clear()
        ax = self.figure.add_subplot(111)
        choice = self.chart_var.get()

        if choice == CHART_OPTIONS[0]:
            self._plot_monthly_bar(ax)
        elif choice == CHART_OPTIONS[1]:
            self._plot_category_pie(ax)
        elif choice == CHART_OPTIONS[2]:
            self._plot_yearly_line(ax)
        elif choice == CHART_OPTIONS[3]:
            self._plot_daily_trend(ax)
        elif choice == CHART_OPTIONS[4]:
            self._plot_payment_mode(ax)
        elif choice == CHART_OPTIONS[5]:
            self._plot_purchased_vs_pending(ax)

        self.figure.tight_layout()
        self.canvas.draw()

    def _plot_monthly_bar(self, ax) -> None:
        data = self.db.get_monthly_summary(self.year_var.get())
        months = list(data.keys())
        totals = list(data.values())
        ax.bar([m[:3] for m in months], totals, color="#2f6feb")
        ax.set_title(f"Monthly Expenses - {self.year_var.get()}")
        ax.set_ylabel("Amount")
        ax.tick_params(axis="x", rotation=45)

    def _plot_category_pie(self, ax) -> None:
        data = self.db.get_category_totals(purchased_only=True)
        if not data:
            ax.text(0.5, 0.5, "No purchased expenses yet", ha="center", va="center")
            return
        ax.pie(list(data.values()), labels=list(data.keys()), autopct="%1.1f%%")
        ax.set_title("Category Breakdown (Purchased)")

    def _plot_yearly_line(self, ax) -> None:
        data = self.db.get_yearly_summary()
        if not data:
            ax.text(0.5, 0.5, "No purchased expenses yet", ha="center", va="center")
            return
        years = sorted(data.keys())
        totals = [data[y] for y in years]
        ax.plot(years, totals, marker="o", color="#1e8e3e")
        ax.set_title("Yearly Expense Trend")
        ax.set_ylabel("Amount")

    def _plot_daily_trend(self, ax) -> None:
        data = self.db.get_daily_totals(days=30)
        if not data:
            ax.text(0.5, 0.5, "No purchased expenses in the last 30 days", ha="center", va="center")
            return
        dates = sorted(data.keys())
        totals = [data[d] for d in dates]
        ax.plot(dates, totals, marker="o", color="#d93025")
        ax.set_title("Daily Expense Trend (Last 30 Days)")
        ax.tick_params(axis="x", rotation=70, labelsize=7)

    def _plot_payment_mode(self, ax) -> None:
        data = self.db.get_payment_mode_totals(purchased_only=True)
        if not data:
            ax.text(0.5, 0.5, "No purchased expenses yet", ha="center", va="center")
            return
        ax.bar(list(data.keys()), list(data.values()), color=["#2f6feb", "#f4b400"])
        ax.set_title("Payment Mode Breakdown (Purchased)")
        ax.set_ylabel("Amount")

    def _plot_purchased_vs_pending(self, ax) -> None:
        purchased, pending = self.db.get_purchased_vs_pending_counts()
        if purchased + pending == 0:
            ax.text(0.5, 0.5, "No expenses yet", ha="center", va="center")
            return
        ax.pie([purchased, pending], labels=["Purchased", "Pending"],
               colors=["#1e8e3e", "#d93025"], autopct="%1.1f%%")
        ax.set_title("Purchased vs Pending (Count)")


# ============================================================================
# --- from reports.py --------------------------------------------------
# ============================================================================
REPORT_TYPES = [
    "Daily Report", "Weekly Report", "Monthly Report", "Yearly Report",
    "Category-wise Report", "Payment Mode Report", "Purchased vs Pending Report",
    "Account Balances & Transactions Report",
]


class ReportsFrame(ttk.Frame):
    def __init__(self, parent, db: DatabaseManager, bus: EventBus, config_manager):
        super().__init__(parent)
        self.db = db
        self.bus = bus
        self.config_manager = config_manager

        ttk.Label(self, text="Reports", style="Header.TLabel").pack(anchor="w", padx=16, pady=(16, 8))

        top = ttk.Frame(self)
        top.pack(fill="x", padx=16)
        ttk.Label(top, text="Report type:", style="TLabel").pack(side="left")
        self.report_var = tk.StringVar(value=REPORT_TYPES[0])
        ttk.Combobox(top, textvariable=self.report_var, values=REPORT_TYPES,
                     state="readonly", width=28).pack(side="left", padx=8)

        self.include_pending_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(top, text="Include pending items", variable=self.include_pending_var
                         ).pack(side="left", padx=(20, 8))

        ttk.Button(top, text="Generate", style="Accent.TButton",
                   command=self.generate).pack(side="left", padx=8)
        ttk.Button(top, text="Export as PDF", command=self.export_pdf).pack(side="left", padx=8)

        text_frame = ttk.Frame(self)
        text_frame.pack(fill="both", expand=True, padx=16, pady=12)
        self.output = tk.Text(text_frame, wrap="word", font=("Consolas", 10))
        self.output.pack(fill="both", expand=True)

        self.bus.subscribe(DATA_CHANGED, lambda: self.generate())
        self.generate()

    # ------------------------------------------------------------------ #
    def _build_report_text(self) -> str:
        currency = self.config_manager.config.currency_symbol
        report_type = self.report_var.get()
        include_pending = self.include_pending_var.get()
        status_filter = "all" if include_pending else "purchased"
        lines = [f"{report_type}", "=" * 60, ""]

        if report_type == "Daily Report":
            today = datetime.now().strftime("%Y-%m-%d")
            rows, total = self.db.query_expenses(date_filter=today, purchased_filter=status_filter, limit=10000)
            lines += self._format_rows(rows, currency)
            lines.append(f"\nTotal for {today}: {currency}{sum(r.amount for r in rows if r.purchased or include_pending):,.2f}")

        elif report_type == "Weekly Report":
            today = datetime.now().date()
            start = today - timedelta(days=today.weekday())
            all_rows = []
            rows, total = self.db.query_expenses(purchased_filter=status_filter, limit=100000)
            for r in rows:
                try:
                    d = datetime.strptime(r.date, "%Y-%m-%d").date()
                    if start <= d <= today:
                        all_rows.append(r)
                except ValueError:
                    continue
            lines += self._format_rows(all_rows, currency)
            lines.append(f"\nTotal this week: {currency}{sum(r.amount for r in all_rows):,.2f}")

        elif report_type == "Monthly Report":
            month_year = datetime.now().strftime("%m-%Y")
            rows, total = self.db.query_expenses(month_filter=month_year, purchased_filter=status_filter, limit=100000)
            lines += self._format_rows(rows, currency)
            lines.append(f"\nTotal for {month_year}: {currency}{sum(r.amount for r in rows):,.2f}")

        elif report_type == "Yearly Report":
            year = datetime.now().strftime("%Y")
            rows, total = self.db.query_expenses(year_filter=year, purchased_filter=status_filter, limit=100000)
            lines += self._format_rows(rows, currency)
            lines.append(f"\nTotal for {year}: {currency}{sum(r.amount for r in rows):,.2f}")

        elif report_type == "Category-wise Report":
            totals = self.db.get_category_totals(purchased_only=not include_pending)
            for cat, total in totals.items():
                lines.append(f"{cat:<25} {currency}{total:,.2f}")
            lines.append(f"\nGrand Total: {currency}{sum(totals.values()):,.2f}")

        elif report_type == "Payment Mode Report":
            totals = self.db.get_payment_mode_totals(purchased_only=not include_pending)
            for mode, total in totals.items():
                lines.append(f"{mode:<25} {currency}{total:,.2f}")
            lines.append(f"\nGrand Total: {currency}{sum(totals.values()):,.2f}")

        elif report_type == "Purchased vs Pending Report":
            purchased, pending = self.db.get_purchased_vs_pending_counts()
            grand_total = self.db.get_grand_total()
            lines.append(f"Purchased items: {purchased}")
            lines.append(f"Pending items:   {pending}")
            lines.append(f"\nTotal (purchased only): {currency}{grand_total:,.2f}")

        elif report_type == "Account Balances & Transactions Report":
            lines.append(f"Cash Balance:      {currency}{self.db.get_cash_balance():,.2f}")
            lines.append(f"UPI Balance:       {currency}{self.db.get_upi_balance():,.2f}")
            lines.append(f"Total Balance:     {currency}{self.db.get_total_balance():,.2f}")
            lines.append(f"Available Balance: {currency}{self.db.get_available_balance():,.2f}")
            lines.append("")
            lines.append("Recent Transactions:")
            lines.append(f"{'Date/Time':<22}{'Type':<20}{'Account':<10}{'Amount':>12}{'Balance After':>16}")
            lines.append("-" * 80)
            txns, _ = self.db.get_transactions(limit=200)
            for t in txns:
                lines.append(
                    f"{t['timestamp']:<22}{t['type']:<20}{t['account']:<10}"
                    f"{currency}{t['amount']:>10,.2f}{currency}{t['balance_after']:>14,.2f}"
                )

        lines.append(f"\nGenerated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        if not include_pending and report_type not in ("Purchased vs Pending Report",
                                                         "Account Balances & Transactions Report"):
            lines.append("(Pending items excluded - enable 'Include pending items' to show them.)")
        return "\n".join(lines)

    @staticmethod
    def _format_rows(rows, currency) -> list:
        lines = [f"{'Date':<12}{'Product':<22}{'Category':<16}{'Amount':>12}  Status"]
        lines.append("-" * 70)
        for r in rows:
            status = "Purchased" if r.purchased else "Pending"
            lines.append(f"{r.date:<12}{r.product[:20]:<22}{r.category[:14]:<16}"
                         f"{currency}{r.amount:>10,.2f}  {status}")
        return lines

    def generate(self) -> None:
        text = self._build_report_text()
        self.output.delete("1.0", "end")
        self.output.insert("1.0", text)

    def export_pdf(self) -> None:
        default_name = self.report_var.get().replace(" ", "_") + ".pdf"
        path = filedialog.asksaveasfilename(
            defaultextension=".pdf", initialfile=default_name,
            initialdir=self.config_manager.config.export_folder,
            filetypes=[("PDF Files", "*.pdf")],
        )
        if not path:
            return
        try:
            generate_report_pdf(path, self.report_var.get(), self.output.get("1.0", "end"))
            messagebox.showinfo("Exported", f"Report exported to:\n{path}")
        except Exception as exc:
            messagebox.showerror("Export Failed", str(exc))


# ============================================================================
# --- from receipts_frame.py -------------------------------------------
# ============================================================================
SCOPES = ["Individual Expense (by ID)", "Daily", "Weekly", "Monthly", "Yearly"]


class ReceiptsFrame(ttk.Frame):
    def __init__(self, parent, db: DatabaseManager, bus: EventBus, config_manager):
        super().__init__(parent)
        self.db = db
        self.bus = bus
        self.config_manager = config_manager

        ttk.Label(self, text="Receipt Generation", style="Header.TLabel").pack(
            anchor="w", padx=16, pady=(16, 8))

        form = ttk.Frame(self, style="Surface.TFrame", padding=16)
        form.pack(fill="x", padx=16, pady=8)

        ttk.Label(form, text="Scope:", style="Surface.TLabel").grid(row=0, column=0, sticky="w", pady=6)
        self.scope_var = tk.StringVar(value=SCOPES[1])
        scope_combo = ttk.Combobox(form, textvariable=self.scope_var, values=SCOPES,
                                    state="readonly", width=26)
        scope_combo.grid(row=0, column=1, sticky="w", pady=6, padx=8)
        scope_combo.bind("<<ComboboxSelected>>", lambda e: self._update_fields())

        ttk.Label(form, text="Expense ID:", style="Surface.TLabel").grid(row=1, column=0, sticky="w", pady=6)
        self.expense_id_var = tk.StringVar()
        self.expense_id_entry = ttk.Entry(form, textvariable=self.expense_id_var, width=28)
        self.expense_id_entry.grid(row=1, column=1, sticky="w", pady=6, padx=8)

        ttk.Label(form, text="Date (YYYY-MM-DD):", style="Surface.TLabel").grid(row=2, column=0, sticky="w", pady=6)
        self.date_var = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        self.date_entry = ttk.Entry(form, textvariable=self.date_var, width=28)
        self.date_entry.grid(row=2, column=1, sticky="w", pady=6, padx=8)

        ttk.Label(form, text="Month (MM-YYYY):", style="Surface.TLabel").grid(row=3, column=0, sticky="w", pady=6)
        self.month_var = tk.StringVar(value=datetime.now().strftime("%m-%Y"))
        self.month_entry = ttk.Entry(form, textvariable=self.month_var, width=28)
        self.month_entry.grid(row=3, column=1, sticky="w", pady=6, padx=8)

        ttk.Label(form, text="Year (YYYY):", style="Surface.TLabel").grid(row=4, column=0, sticky="w", pady=6)
        self.year_var = tk.StringVar(value=datetime.now().strftime("%Y"))
        self.year_entry = ttk.Entry(form, textvariable=self.year_var, width=28)
        self.year_entry.grid(row=4, column=1, sticky="w", pady=6, padx=8)

        ttk.Label(form, text="Owner Name (optional):", style="Surface.TLabel").grid(row=5, column=0, sticky="w", pady=6)
        self.owner_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.owner_var, width=28).grid(row=5, column=1, sticky="w", pady=6, padx=8)

        self.include_pending_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(form, text="Include pending items in batch receipts",
                         variable=self.include_pending_var).grid(row=6, column=0, columnspan=2, sticky="w", pady=6)

        ttk.Button(form, text="Generate PDF Receipt", style="Accent.TButton",
                   command=self.generate).grid(row=7, column=0, columnspan=2, pady=16)

        self.status_label = ttk.Label(self, text="", style="TLabel")
        self.status_label.pack(anchor="w", padx=16)

        self._update_fields()

    def _update_fields(self) -> None:
        scope = self.scope_var.get()
        for widget in (self.expense_id_entry, self.date_entry, self.month_entry, self.year_entry):
            widget.configure(state="disabled")
        if scope == SCOPES[0]:
            self.expense_id_entry.configure(state="normal")
        elif scope == SCOPES[1]:
            self.date_entry.configure(state="normal")
        elif scope == SCOPES[2]:
            self.date_entry.configure(state="normal")
        elif scope == SCOPES[3]:
            self.month_entry.configure(state="normal")
        elif scope == SCOPES[4]:
            self.year_entry.configure(state="normal")

    def generate(self) -> None:
        scope = self.scope_var.get()
        currency = self.config_manager.config.currency_symbol
        owner = self.owner_var.get().strip() or None
        include_pending = self.include_pending_var.get()
        status_filter = "all" if include_pending else "purchased"

        try:
            if scope == SCOPES[0]:
                expense_id = int(self.expense_id_var.get().strip())
                expense = self.db.get_expense(expense_id)
                if not expense:
                    messagebox.showerror("Not Found", f"No expense with id {expense_id}.")
                    return
                default_name = f"receipt_{expense_id}.pdf"
                path = filedialog.asksaveasfilename(
                    defaultextension=".pdf", initialfile=default_name,
                    initialdir=self.config_manager.config.export_folder,
                    filetypes=[("PDF Files", "*.pdf")])
                if not path:
                    return
                generate_expense_receipt(path, expense, currency, owner)

            elif scope == SCOPES[1]:
                date = self.date_var.get().strip()
                rows, _ = self.db.query_expenses(date_filter=date, purchased_filter=status_filter, limit=100000)
                path = self._ask_save(f"daily_receipt_{date}.pdf")
                if not path:
                    return
                generate_batch_receipt(path, f"Daily Receipt - {date}", rows, currency, owner)

            elif scope == SCOPES[2]:
                anchor_date = datetime.strptime(self.date_var.get().strip(), "%Y-%m-%d").date()
                start = anchor_date - timedelta(days=anchor_date.weekday())
                end = start + timedelta(days=6)
                rows, _ = self.db.query_expenses(purchased_filter=status_filter, limit=1000000)
                rows = [r for r in rows if start.isoformat() <= r.date <= end.isoformat()]
                path = self._ask_save(f"weekly_receipt_{start}_{end}.pdf")
                if not path:
                    return
                generate_batch_receipt(path, f"Weekly Receipt - {start} to {end}", rows, currency, owner)

            elif scope == SCOPES[3]:
                month_year = self.month_var.get().strip()
                rows, _ = self.db.query_expenses(month_filter=month_year, purchased_filter=status_filter, limit=1000000)
                path = self._ask_save(f"monthly_receipt_{month_year}.pdf")
                if not path:
                    return
                generate_batch_receipt(path, f"Monthly Receipt - {month_year}", rows, currency, owner)

            elif scope == SCOPES[4]:
                year = self.year_var.get().strip()
                rows, _ = self.db.query_expenses(year_filter=year, purchased_filter=status_filter, limit=1000000)
                path = self._ask_save(f"yearly_receipt_{year}.pdf")
                if not path:
                    return
                generate_batch_receipt(path, f"Yearly Receipt - {year}", rows, currency, owner)

            self.status_label.config(text=f"Receipt generated: {path}")
            messagebox.showinfo("Success", f"Receipt saved to:\n{path}")
        except ValueError:
            messagebox.showerror("Invalid Input", "Please check the date/month/year/id fields.")
        except Exception as exc:
            messagebox.showerror("Error", str(exc))

    def _ask_save(self, default_name: str):
        return filedialog.asksaveasfilename(
            defaultextension=".pdf", initialfile=default_name,
            initialdir=self.config_manager.config.export_folder,
            filetypes=[("PDF Files", "*.pdf")])


# ============================================================================
# --- from data_frame.py -----------------------------------------------
# ============================================================================
class DataFrame(ttk.Frame):
    def __init__(self, parent, db: DatabaseManager, bus: EventBus, config_manager):
        super().__init__(parent)
        self.db = db
        self.bus = bus
        self.config_manager = config_manager

        ttk.Label(self, text="Export, Backup & Restore", style="Header.TLabel").pack(
            anchor="w", padx=16, pady=(16, 8))

        export_box = ttk.LabelFrame(self, text="Export")
        export_box.pack(fill="x", padx=16, pady=8)
        ttk.Button(export_box, text="Export to CSV", command=self.export_csv).pack(
            side="left", padx=10, pady=10)
        ttk.Button(export_box, text="Export to Excel", command=self.export_excel).pack(
            side="left", padx=10, pady=10)

        import_box = ttk.LabelFrame(self, text="Import")
        import_box.pack(fill="x", padx=16, pady=8)
        ttk.Button(import_box, text="Import from CSV", command=self.import_csv).pack(
            side="left", padx=10, pady=10)

        backup_box = ttk.LabelFrame(self, text="Backup & Restore")
        backup_box.pack(fill="x", padx=16, pady=8)
        ttk.Button(backup_box, text="Backup Database", command=self.backup).pack(
            side="left", padx=10, pady=10)
        ttk.Button(backup_box, text="Restore Database", command=self.restore).pack(
            side="left", padx=10, pady=10)

        self.status_label = ttk.Label(self, text="", style="TLabel")
        self.status_label.pack(anchor="w", padx=16, pady=8)

    def _set_status(self, text: str) -> None:
        self.status_label.config(text=text)

    def export_csv(self) -> None:
        path = filedialog.asksaveasfilename(
            defaultextension=".csv", initialfile="expenses.csv",
            initialdir=self.config_manager.config.export_folder,
            filetypes=[("CSV Files", "*.csv")])
        if not path:
            return
        try:
            n = export_to_csv(self.db, path)
            self._set_status(f"Exported {n} rows to {path}")
            messagebox.showinfo("Export Complete", f"Exported {n} expenses to CSV.")
        except Exception as exc:
            messagebox.showerror("Export Failed", str(exc))

    def export_excel(self) -> None:
        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx", initialfile="expenses.xlsx",
            initialdir=self.config_manager.config.export_folder,
            filetypes=[("Excel Files", "*.xlsx")])
        if not path:
            return
        try:
            n = export_to_excel(self.db, path)
            self._set_status(f"Exported {n} rows to {path}")
            messagebox.showinfo("Export Complete", f"Exported {n} expenses to Excel.")
        except Exception as exc:
            messagebox.showerror("Export Failed", str(exc))

    def import_csv(self) -> None:
        path = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
        if not path:
            return
        try:
            n = import_from_csv(self.db, path)
            self._set_status(f"Imported {n} rows from {path}")
            messagebox.showinfo("Import Complete", f"Imported {n} expenses.")
            self.bus.publish(DATA_CHANGED)
        except Exception as exc:
            messagebox.showerror("Import Failed", str(exc))

    def backup(self) -> None:
        try:
            path = backup_database(self.db, self.config_manager.config.backup_folder)
            self._set_status(f"Backup created at {path}")
            messagebox.showinfo("Backup Complete", f"Database backed up to:\n{path}")
        except Exception as exc:
            messagebox.showerror("Backup Failed", str(exc))

    def restore(self) -> None:
        path = filedialog.askopenfilename(
            initialdir=self.config_manager.config.backup_folder,
            filetypes=[("SQLite Database", "*.db")])
        if not path:
            return
        if not messagebox.askyesno(
            "Confirm Restore",
            "Restoring will REPLACE all current data with the selected backup. Continue?"
        ):
            return
        try:
            restore_database(self.db, path)
            self._set_status(f"Restored from {path}")
            messagebox.showinfo("Restore Complete", "Database restored successfully.")
            self.bus.publish(DATA_CHANGED)
        except Exception as exc:
            messagebox.showerror("Restore Failed", str(exc))


# ============================================================================
# --- from settings_window.py ------------------------------------------
# ============================================================================
CURRENCIES = ["\u20b9", "$", "\u20ac", "\u00a3"]  # ₹ $ € £


class SettingsDialog(tk.Toplevel):
    def __init__(self, parent: tk.Misc, config_manager: ConfigManager, on_saved: Callable[[], None]):
        super().__init__(parent)
        self.config_manager = config_manager
        self.on_saved = on_saved
        colors = palette(config_manager.config.theme)

        self.title("Settings")
        self.geometry("460x520")
        self.resizable(False, False)
        self.configure(bg=colors["surface"])
        self.transient(parent)
        self.grab_set()

        cfg = config_manager.config
        pad = {"padx": 16, "pady": 8}
        frm = ttk.Frame(self, style="Surface.TFrame")
        frm.pack(fill="both", expand=True)

        row = 0
        ttk.Label(frm, text="Currency", style="Surface.TLabel").grid(row=row, column=0, sticky="w", **pad)
        self.currency_var = tk.StringVar(value=cfg.currency_symbol)
        ttk.Combobox(frm, textvariable=self.currency_var, values=CURRENCIES,
                     state="readonly", width=10).grid(row=row, column=1, sticky="w", **pad)
        row += 1

        ttk.Label(frm, text="Theme", style="Surface.TLabel").grid(row=row, column=0, sticky="w", **pad)
        self.theme_var = tk.StringVar(value=cfg.theme)
        ttk.Combobox(frm, textvariable=self.theme_var, values=["light", "dark"],
                     state="readonly", width=10).grid(row=row, column=1, sticky="w", **pad)
        row += 1

        ttk.Label(frm, text="Default Payment Mode", style="Surface.TLabel").grid(row=row, column=0, sticky="w", **pad)
        self.payment_var = tk.StringVar(value=cfg.default_payment_mode)
        ttk.Combobox(frm, textvariable=self.payment_var, values=["Cash", "UPI"],
                     state="readonly", width=10).grid(row=row, column=1, sticky="w", **pad)
        row += 1

        self.autosave_var = tk.BooleanVar(value=cfg.auto_save)
        ttk.Checkbutton(frm, text="Enable Auto-Save", variable=self.autosave_var
                         ).grid(row=row, column=0, columnspan=2, sticky="w", **pad)
        row += 1

        ttk.Label(frm, text="Backup Folder", style="Surface.TLabel").grid(row=row, column=0, sticky="w", **pad)
        self.backup_var = tk.StringVar(value=cfg.backup_folder)
        ttk.Entry(frm, textvariable=self.backup_var, width=28).grid(row=row, column=1, **pad)
        ttk.Button(frm, text="Browse", command=self._browse_backup).grid(row=row, column=2, **pad)
        row += 1

        ttk.Label(frm, text="Export Folder", style="Surface.TLabel").grid(row=row, column=0, sticky="w", **pad)
        self.export_var = tk.StringVar(value=cfg.export_folder)
        ttk.Entry(frm, textvariable=self.export_var, width=28).grid(row=row, column=1, **pad)
        ttk.Button(frm, text="Browse", command=self._browse_export).grid(row=row, column=2, **pad)
        row += 1

        note = ttk.Label(
            frm, style="Muted.TLabel", justify="left",
            text="Theme changes apply after saving and take effect\nimmediately across the whole application.",
        )
        note.grid(row=row, column=0, columnspan=3, sticky="w", padx=16, pady=(10, 0))
        row += 1

        btns = ttk.Frame(frm, style="Surface.TFrame")
        btns.grid(row=row, column=0, columnspan=3, pady=24)
        ttk.Button(btns, text="Save", style="Accent.TButton", command=self._save).pack(side="left", padx=8)
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="left", padx=8)

    def _browse_backup(self):
        folder = filedialog.askdirectory()
        if folder:
            self.backup_var.set(folder)

    def _browse_export(self):
        folder = filedialog.askdirectory()
        if folder:
            self.export_var.set(folder)

    def _save(self):
        self.config_manager.update(
            currency_symbol=self.currency_var.get(),
            theme=self.theme_var.get(),
            default_payment_mode=self.payment_var.get(),
            auto_save=self.autosave_var.get(),
            backup_folder=self.backup_var.get(),
            export_folder=self.export_var.get(),
        )
        messagebox.showinfo("Settings Saved", "Your settings have been saved.")
        self.on_saved()
        self.destroy()


# ============================================================================
# --- from app.py ------------------------------------------------------
# ============================================================================
NAV_ITEMS = ["Dashboard", "Expenses", "Accounts", "Income", "Summary",
             "Charts", "Reports", "Receipts", "Data Tools"]


class ExpenseTrackerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.config_manager = ConfigManager()
        self.db = DatabaseManager(self.config_manager.config.db_path)
        self.bus = EventBus()

        self.title("Daily Expense Tracker")
        self.geometry(self.config_manager.config.window_geometry)
        self.minsize(1000, 640)

        self.colors = apply_theme(self, self.config_manager.config.theme)

        self._build_status_bar()
        self._build_layout()
        self._bind_shortcuts()

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ------------------------------------------------------------------ #
    def _build_layout(self) -> None:
        root = ttk.Frame(self)
        root.pack(fill="both", expand=True)

        # Sidebar
        sidebar = ttk.Frame(root, style="Sidebar.TFrame", width=200)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        ttk.Label(sidebar, text="\U0001F4B0 Expense\nTracker", style="Sidebar.TLabel",
                  font=("Segoe UI", 14, "bold")).pack(pady=(24, 20), padx=16, anchor="w")

        self.nav_buttons = {}
        for name in NAV_ITEMS:
            btn = ttk.Button(sidebar, text=name, style="Sidebar.TButton",
                              command=lambda n=name: self.show_panel(n))
            btn.pack(fill="x", padx=12, pady=4)
            self.nav_buttons[name] = btn

        ttk.Button(sidebar, text="\u2699 Settings", style="Sidebar.TButton",
                   command=self.open_settings).pack(fill="x", padx=12, pady=(30, 4))

        # Main content area (a container that stacks all panels; only one visible)
        self.content = ttk.Frame(root)
        self.content.pack(side="left", fill="both", expand=True)

        self.panels = {
            "Dashboard": DashboardFrame(self.content, self.db, self.bus, self.config_manager),
            "Expenses": ExpenseTableFrame(self.content, self.db, self.bus, self.config_manager),
            "Accounts": AccountsFrame(self.content, self.db, self.bus, self.config_manager),
            "Income": IncomeFrame(self.content, self.db, self.bus, self.config_manager),
            "Summary": SummaryFrame(self.content, self.db, self.bus, self.config_manager),
            "Charts": ChartsFrame(self.content, self.db, self.bus, self.config_manager),
            "Reports": ReportsFrame(self.content, self.db, self.bus, self.config_manager),
            "Receipts": ReceiptsFrame(self.content, self.db, self.bus, self.config_manager),
            "Data Tools": DataFrame(self.content, self.db, self.bus, self.config_manager),
        }
        for panel in self.panels.values():
            panel.place(relx=0, rely=0, relwidth=1, relheight=1)

        self.show_panel("Dashboard")

    def show_panel(self, name: str) -> None:
        self.panels[name].tkraise()
        self._set_status(f"Viewing: {name}")

    def _build_status_bar(self) -> None:
        self.status_bar = ttk.Frame(self, style="Toolbar.TFrame")
        self.status_bar.pack(side="bottom", fill="x")
        self.status_label = ttk.Label(self.status_bar, text="Ready", style="Surface.TLabel")
        self.status_label.pack(side="left", padx=12, pady=4)

        self.db_path_label = ttk.Label(
            self.status_bar, text=f"DB: {self.config_manager.config.db_path}", style="Muted.TLabel")
        self.db_path_label.pack(side="right", padx=12, pady=4)

        self.bus.subscribe(DATA_CHANGED, self._on_data_changed)

    def _on_data_changed(self) -> None:
        self._set_status("Data updated - all views refreshed automatically.")

    def _set_status(self, text: str) -> None:
        self.status_label.config(text=text)

    def _bind_shortcuts(self) -> None:
        self.bind("<Control-q>", lambda e: self._on_close())
        self.bind("<Control-1>", lambda e: self.show_panel("Dashboard"))
        self.bind("<Control-2>", lambda e: self.show_panel("Expenses"))
        self.bind("<Control-3>", lambda e: self.show_panel("Summary"))
        self.bind("<Control-4>", lambda e: self.show_panel("Charts"))
        self.bind("<Control-5>", lambda e: self.show_panel("Reports"))

    def open_settings(self) -> None:
        SettingsDialog(self, self.config_manager, on_saved=self._apply_theme_change)

    def _apply_theme_change(self) -> None:
        self.colors = apply_theme(self, self.config_manager.config.theme)
        # Rebuild layout so every panel picks up the new palette / currency.
        # Old panels are being destroyed, so start with a fresh EventBus -
        # otherwise destroyed widgets would remain subscribed and raise
        # "invalid command name" errors the next time data changes.
        for child in self.winfo_children():
            child.destroy()
        self.bus = EventBus()
        self._build_status_bar()
        self._build_layout()
        self._set_status("Settings updated.")

    def _on_close(self) -> None:
        self.config_manager.update(window_geometry=self.geometry())
        self.db.close()
        self.destroy()


def run() -> None:
    app = ExpenseTrackerApp()
    app.mainloop()


# ============================================================================
# Entry point
# ============================================================================
if __name__ == "__main__":
    run()
